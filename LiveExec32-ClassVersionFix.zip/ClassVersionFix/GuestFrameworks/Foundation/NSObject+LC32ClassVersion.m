#import <Foundation/Foundation+LC32.h>

#import <objc/runtime.h>

/*
 * Foundation declares the legacy NSObject class-versioning methods
 * (+version / +setVersion:) and implements them on top of the libobjc
 * class_getVersion / class_setVersion primitives. The guest Foundation
 * shim did not provide them, so a message such as [SomeClass version]
 * fell through to forwarding and ended in doesNotRecognizeSelector:.
 * Luxor Evolved Lite hits this at startup on iOS_AppDelegate.
 *
 * The version is stored per class by libobjc and is not inherited, which
 * matches Apple's behavior.
 */
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-implementations"
#pragma clang diagnostic ignored "-Wobjc-protocol-method-implementation"
@implementation NSObject (LC32ClassVersion)

+ (NSInteger)version {
    return (NSInteger)class_getVersion(self);
}

+ (void)setVersion:(NSInteger)version {
    class_setVersion(self, (int)version);
}

@end
#pragma clang diagnostic pop
