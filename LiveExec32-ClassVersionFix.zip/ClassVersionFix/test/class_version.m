#import <Foundation/Foundation.h>
#include <stdio.h>

#pragma clang diagnostic ignored "-Wdeprecated-declarations"

static unsigned checks, failures;
static void check(const char *name, BOOL pass) {
    printf("class-version-%s: %s\n", name, pass ? "PASS" : "FAIL");
    ++checks; failures += !pass;
}

@interface VersionProbe : NSObject
@end
@implementation VersionProbe
@end

@interface VersionProbeChild : VersionProbe
@end
@implementation VersionProbeChild
@end

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    @autoreleasepool {
        check("responds", [VersionProbe respondsToSelector:@selector(version)] &&
            [VersionProbe respondsToSelector:@selector(setVersion:)]);
        check("default-zero", [VersionProbe version] == 0);

        [VersionProbe setVersion:7];
        check("set-get", [VersionProbe version] == 7);

        /* The version belongs to one class; it is not inherited. */
        check("not-inherited", [VersionProbeChild version] == 0 &&
            [NSObject version] == 0);

        [VersionProbeChild setVersion:-3];
        check("negative", [VersionProbeChild version] == -3 &&
            [VersionProbe version] == 7);
    }
    return failures ? 1 : 0;
}
