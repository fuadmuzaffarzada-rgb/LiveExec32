#import <AudioToolbox/AudioToolbox.h>
#import <LC32/LC32.h>

#include <errno.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#import "LC32AudioToolboxBridge.h"

#ifndef LC32_TRACE_AUDIO_OUTPUT
#define LC32_TRACE_AUDIO_OUTPUT 0
#endif

#include <stdio.h>
#include <sys/stat.h>
#include <mach-o/dyld.h>

static pthread_once_t LC32AudioToolboxDispatcherOnce = PTHREAD_ONCE_INIT;
static uint64_t LC32AudioToolboxDispatcherAddress;

static void LC32AudioToolboxResolveDispatcher(void) {
    LC32AudioToolboxDispatcherAddress =
        LC32Dlsym("LC32_AudioToolbox_Dispatch", YES);
}

/* DIAGNOSTIC: records audio bridge calls so a missing-sound report can show
 * which call fails. Writes to stderr and to Documents/lc32-audio-log.txt in
 * the guest container. Failures are always logged; successes only for the
 * session/queue/RemoteIO setup calls. Capped so it cannot grow unbounded. */
static pthread_mutex_t LC32AudioLogMutex = PTHREAD_MUTEX_INITIALIZER;
static unsigned LC32AudioLogCount;

static void LC32AudioLog(uint32_t opcode, uint32_t status,
                         const uint64_t *slots, uint32_t slotCount) {
    const int failed = status != 0;
    const int setup = opcode == LC32AudioToolboxOpAudioSessionGetProperty ||
        opcode == LC32AudioToolboxOpAudioSessionSetActive ||
        opcode == LC32AudioToolboxOpAudioSessionSetProperty ||
        opcode == LC32AudioToolboxOpAudioQueueNewOutput ||
        opcode == LC32AudioToolboxOpAudioQueueStart ||
        opcode == LC32AudioToolboxOpRemoteIOOutputStart ||
        opcode == LC32AudioToolboxOpAudioConverterNew ||
        opcode == LC32AudioToolboxOpExtAudioFileOpenURL ||
        opcode == LC32AudioToolboxOpAudioFileOpenURL;
    if(!failed && !setup) return;
    pthread_mutex_lock(&LC32AudioLogMutex);
    if(LC32AudioLogCount < 400) {
        ++LC32AudioLogCount;
        char line[160];
        snprintf(line, sizeof(line),
            "LC32AudioLog #%u op=%u status=%d (0x%08x) slot0=0x%x slot1=0x%x\n",
            LC32AudioLogCount, opcode, (int)status, status,
            slotCount > 0 ? (unsigned)slots[0] : 0,
            slotCount > 1 ? (unsigned)slots[1] : 0);
        fputs(line, stderr);
        /* 1) Top level of LiveContainer's Documents folder, derived from the
         * game's executable path (.../Documents/Applications/<app>/<exe>).
         * This is the folder the Files app shows for LiveContainer. */
        char exe[1024];
        uint32_t exeSize = sizeof(exe);
        if(_NSGetExecutablePath(exe, &exeSize) == 0) {
            char *marker = strstr(exe, "/Documents/");
            if(marker) {
                strcpy(marker + strlen("/Documents/"), "lc32-audio-log.txt");
                FILE *file = fopen(exe, "a");
                if(file) { fputs(line, file); fclose(file); }
            }
        }
        /* 2) The guest's own HOME/Documents, created if missing. */
        const char *home = getenv("HOME");
        if(home) {
            char dir[1024], path[1100];
            snprintf(dir, sizeof(dir), "%s/Documents", home);
            mkdir(dir, 0755);
            snprintf(path, sizeof(path), "%s/lc32-audio-log.txt", dir);
            FILE *file = fopen(path, "a");
            if(file) { fputs(line, file); fclose(file); }
        }
    }
    pthread_mutex_unlock(&LC32AudioLogMutex);
}

static uint32_t LC32AudioToolboxDispatch(LC32AudioToolboxOpcode opcode,
                                         const uint64_t *slots,
                                         uint32_t slotCount) {
    if(slotCount > LC32AudioToolboxMaxSlots) return (uint32_t)kAudio_ParamError;
    pthread_once(&LC32AudioToolboxDispatcherOnce,
        LC32AudioToolboxResolveDispatcher);
    if(!LC32AudioToolboxDispatcherAddress) return (uint32_t)kAudio_ParamError;

    LC32AudioToolboxCall call = {
        .version = LC32AudioToolboxABIVersion,
        .slotCount = slotCount,
    };
    if(slotCount) memcpy(call.slots, slots, slotCount * sizeof(*slots));
    const uint32_t result = LC32InvokeHostCRet32(
        LC32AudioToolboxDispatcherAddress,
        (uint32_t)opcode, (uint32_t)(uintptr_t)&call);
    LC32AudioLog((uint32_t)opcode, result, slots, slotCount);
    return result;
}

#define LC32_AUDIO_CALL(opcode, ...) \
    LC32AudioToolboxDispatch((opcode), (const uint64_t[]){__VA_ARGS__}, \
        (uint32_t)(sizeof((const uint64_t[]){__VA_ARGS__}) / sizeof(uint64_t)))
#define LC32_AUDIO_U32(value) ((uint64_t)(uint32_t)(value))

typedef struct LC32GuestAudioQueueBuffer {
    uint32_t audioDataBytesCapacity;
    uint32_t audioData;
    uint32_t audioDataByteSize;
    uint32_t userData;
    uint32_t packetDescriptionCapacity;
    uint32_t packetDescriptions;
    uint32_t packetDescriptionCount;
} LC32GuestAudioQueueBuffer;

typedef struct LC32GuestAudioQueueInputCallbackStorage {
    AudioTimeStamp timeStamp;
    uint32_t packetCount;
    uint32_t packetDescriptions;
} LC32GuestAudioQueueInputCallbackStorage;

typedef struct LC32GuestAudioQueueAllocation {
    struct LC32GuestAudioQueueAllocation *next;
    AudioQueueRef queue;
    LC32GuestAudioQueueInputCallbackStorage callbackStorage;
    LC32GuestAudioQueueBuffer buffer;
} LC32GuestAudioQueueAllocation;

typedef struct LC32GuestAudioQueueLifecycle {
    struct LC32GuestAudioQueueLifecycle *next;
    AudioQueueRef queue;
    pthread_mutex_t mutex;
    uint32_t users;
    BOOL disposing;
    BOOL removed;
} LC32GuestAudioQueueLifecycle;

_Static_assert(sizeof(LC32GuestAudioQueueBuffer) == 28,
    "ARM32 AudioQueueBuffer layout changed");
_Static_assert(sizeof(AudioTimeStamp) == 64,
    "ARM32 AudioTimeStamp layout changed");
_Static_assert(offsetof(LC32GuestAudioQueueInputCallbackStorage,
    packetCount) == 64, "AudioQueue callback scratch layout changed");

static pthread_mutex_t LC32AudioQueueAllocationsMutex =
    PTHREAD_MUTEX_INITIALIZER;
static LC32GuestAudioQueueAllocation *LC32AudioQueueAllocations;
static pthread_mutex_t LC32AudioQueueLifecyclesMutex =
    PTHREAD_MUTEX_INITIALIZER;
static LC32GuestAudioQueueLifecycle *LC32AudioQueueLifecycles;
enum {
    LC32AudioQueueMaximumAllocationBytes = 256u * 1024u * 1024u,
};

static size_t LC32AudioQueueAlign8(size_t value) {
    return (value + 7u) & ~(size_t)7u;
}

static LC32GuestAudioQueueLifecycle *LC32AudioQueueCreateLifecycle(
        AudioQueueRef queue) {
    LC32GuestAudioQueueLifecycle *lifecycle =
        calloc(1, sizeof(*lifecycle));
    if(!lifecycle) return NULL;
    lifecycle->queue = queue;
    if(pthread_mutex_init(&lifecycle->mutex, NULL)) {
        free(lifecycle);
        return NULL;
    }

    pthread_mutex_lock(&LC32AudioQueueLifecyclesMutex);
    for(LC32GuestAudioQueueLifecycle *candidate =
            LC32AudioQueueLifecycles; candidate;
            candidate = candidate->next) {
        if(candidate->queue == queue && !candidate->removed) {
            pthread_mutex_unlock(&LC32AudioQueueLifecyclesMutex);
            pthread_mutex_destroy(&lifecycle->mutex);
            free(lifecycle);
            return NULL;
        }
    }
    lifecycle->next = LC32AudioQueueLifecycles;
    LC32AudioQueueLifecycles = lifecycle;
    pthread_mutex_unlock(&LC32AudioQueueLifecyclesMutex);
    return lifecycle;
}

static void LC32AudioQueueReleaseLifecycleReference(
        LC32GuestAudioQueueLifecycle *lifecycle) {
    BOOL destroy = NO;
    pthread_mutex_lock(&LC32AudioQueueLifecyclesMutex);
    if(lifecycle->users) --lifecycle->users;
    destroy = lifecycle->removed && lifecycle->users == 0;
    pthread_mutex_unlock(&LC32AudioQueueLifecyclesMutex);
    if(destroy) {
        pthread_mutex_destroy(&lifecycle->mutex);
        free(lifecycle);
    }
}

static LC32GuestAudioQueueLifecycle *LC32AudioQueueAcquireLifecycle(
        AudioQueueRef queue) {
    LC32GuestAudioQueueLifecycle *lifecycle = NULL;
    pthread_mutex_lock(&LC32AudioQueueLifecyclesMutex);
    for(LC32GuestAudioQueueLifecycle *candidate =
            LC32AudioQueueLifecycles; candidate;
            candidate = candidate->next) {
        if(candidate->queue == queue && !candidate->removed) {
            lifecycle = candidate;
            ++lifecycle->users;
            break;
        }
    }
    pthread_mutex_unlock(&LC32AudioQueueLifecyclesMutex);
    if(!lifecycle) return NULL;

    pthread_mutex_lock(&lifecycle->mutex);
    if(lifecycle->removed || lifecycle->disposing) {
        pthread_mutex_unlock(&lifecycle->mutex);
        LC32AudioQueueReleaseLifecycleReference(lifecycle);
        return NULL;
    }
    return lifecycle;
}

static void LC32AudioQueueReleaseLifecycle(
        LC32GuestAudioQueueLifecycle *lifecycle) {
    pthread_mutex_unlock(&lifecycle->mutex);
    LC32AudioQueueReleaseLifecycleReference(lifecycle);
}

static void LC32AudioQueueRemoveLifecycleLocked(
        LC32GuestAudioQueueLifecycle *lifecycle) {
    pthread_mutex_lock(&LC32AudioQueueLifecyclesMutex);
    LC32GuestAudioQueueLifecycle **cursor = &LC32AudioQueueLifecycles;
    while(*cursor && *cursor != lifecycle) cursor = &(*cursor)->next;
    if(*cursor == lifecycle) *cursor = lifecycle->next;
    lifecycle->removed = YES;
    pthread_mutex_unlock(&LC32AudioQueueLifecyclesMutex);
}

static void LC32AudioQueueTrackAllocation(
        LC32GuestAudioQueueAllocation *allocation) {
    pthread_mutex_lock(&LC32AudioQueueAllocationsMutex);
    allocation->next = LC32AudioQueueAllocations;
    LC32AudioQueueAllocations = allocation;
    pthread_mutex_unlock(&LC32AudioQueueAllocationsMutex);
}

static void LC32AudioQueueReleaseAllocations(AudioQueueRef queue) {
    LC32GuestAudioQueueAllocation *released = NULL;
    pthread_mutex_lock(&LC32AudioQueueAllocationsMutex);
    LC32GuestAudioQueueAllocation **cursor = &LC32AudioQueueAllocations;
    while(*cursor) {
        LC32GuestAudioQueueAllocation *allocation = *cursor;
        if(allocation->queue != queue) {
            cursor = &allocation->next;
            continue;
        }
        *cursor = allocation->next;
        allocation->next = released;
        released = allocation;
    }
    pthread_mutex_unlock(&LC32AudioQueueAllocationsMutex);
    while(released) {
        LC32GuestAudioQueueAllocation *next = released->next;
        free(released);
        released = next;
    }
}

/* Invoked by the host only after a dispose requested from inside a queue
 * callback has drained all callbacks/users and detached the native mirrors.
 * Keeping this in the guest preserves malloc ownership without leaking every
 * buffer allocated by a queue which disposes itself from its callback. */
static void LC32AudioQueueReleaseDeferredAllocations(AudioQueueRef queue) {
    LC32AudioQueueReleaseAllocations(queue);
}

static void LC32AudioQueueCallbackScope(AudioQueueRef queue, BOOL entering) {
    if(!queue) return;
    (void)LC32_AUDIO_CALL(entering
        ? LC32AudioToolboxOpAudioQueueCallbackEnter
        : LC32AudioToolboxOpAudioQueueCallbackLeave,
        LC32_AUDIO_U32((uintptr_t)queue));
}

static void LC32AudioQueueInvokeInputCallback(
        uint32_t callbackAddress, void *userData, AudioQueueRef queue,
        AudioQueueBufferRef buffer,
        LC32GuestAudioQueueInputCallbackStorage *storage) {
    if(!callbackAddress || !storage) return;
    AudioQueueInputCallback callback =
        (AudioQueueInputCallback)(uintptr_t)callbackAddress;
    LC32AudioQueueCallbackScope(queue, YES);
    @try {
        callback(userData, queue, buffer, &storage->timeStamp,
            storage->packetCount,
            (const AudioStreamPacketDescription *)(uintptr_t)
                storage->packetDescriptions);
    } @finally {
        LC32AudioQueueCallbackScope(queue, NO);
    }
}

static void LC32AudioQueueInvokeOutputCallback(
        uint32_t callbackAddress, void *userData, AudioQueueRef queue,
        AudioQueueBufferRef buffer) {
    if(!callbackAddress) return;
    AudioQueueOutputCallback callback =
        (AudioQueueOutputCallback)(uintptr_t)callbackAddress;
    LC32AudioQueueCallbackScope(queue, YES);
    @try {
        callback(userData, queue, buffer);
    } @finally {
        LC32AudioQueueCallbackScope(queue, NO);
    }
}

static void LC32AudioQueueInvokePropertyListener(
        uint32_t callbackAddress, void *userData, AudioQueueRef queue,
        AudioQueuePropertyID property) {
    if(!callbackAddress) return;
    AudioQueuePropertyListenerProc callback =
        (AudioQueuePropertyListenerProc)(uintptr_t)callbackAddress;
    LC32AudioQueueCallbackScope(queue, YES);
    @try {
        callback(userData, queue, property);
    } @finally {
        LC32AudioQueueCallbackScope(queue, NO);
    }
}

/*
 * The old FMOD output bundled by several 32-bit games configures a RemoteIO
 * AudioUnit directly. A host AudioUnit cannot be exposed as a raw pointer to
 * the guest, and its realtime callback cannot consume guest AudioBufferList
 * pointers. Keep a small guest-owned unit which invokes the guest callback.
 * A private host AudioQueue sink consumes the rendered PCM without ever
 * calling emulated code from its realtime thread; if the host route is not
 * available, the same pump falls back to its original silent timing mode.
 * Besides producing audio, the callback is how old FMOD wakes its mixer thread
 * after consuming its ring buffer.
 */
typedef struct {
    AURenderCallback proc;
    void *userData;
} LC32SilentAudioRenderNotify;

typedef struct {
    AudioUnitPropertyID property;
    AudioUnitPropertyListenerProc proc;
    void *userData;
} LC32AudioPropertyListener;

typedef enum {
    LC32SilentAudioUnitKindRemoteIO = 1,
    LC32SilentAudioUnitKindSpatialMixer = 2,
} LC32SilentAudioUnitKind;

enum {
    LC32SilentAudioMaximumMixerBuses = 32,
    LC32SilentAudioMixerParameterCount = 6,
};

typedef struct LC32SilentAudioUnit {
    uint32_t magic;
    uint32_t referenceCount;
    LC32SilentAudioUnitKind kind;
    AudioStreamBasicDescription format;
    AudioStreamBasicDescription mixerInputFormats[
        LC32SilentAudioMaximumMixerBuses];
    AURenderCallbackStruct mixerRenderCallbacks[
        LC32SilentAudioMaximumMixerBuses];
    AudioUnitParameterValue mixerParameters[
        LC32SilentAudioMaximumMixerBuses]
        [LC32SilentAudioMixerParameterCount];
    AudioUnitParameterValue mixerLinearGains[
        LC32SilentAudioMaximumMixerBuses];
    UInt32 mixerInputBusCount;
    struct LC32SilentAudioUnit *connectedMixer;
    AudioUnitParameterValue outputVolume;
    AURenderCallbackStruct renderCallback;
    LC32SilentAudioRenderNotify *renderNotifies;
    size_t renderNotifyCount;
    LC32AudioPropertyListener *propertyListeners;
    size_t propertyListenerCount;
    pthread_mutex_t mutex;
    pthread_t renderThread;
    uint32_t stopRequested;
    uint32_t started;
    uint32_t hostOutputToken;
    uint32_t hostOutputHealthy;
    uint32_t renderFrames;
    BOOL initialized;
    BOOL renderThreadJoinable;
    BOOL joiningRenderThread;
    BOOL disposed;
} LC32SilentAudioUnit;

typedef struct {
    LC32SilentAudioUnit *unit;
    AudioStreamBasicDescription format;
    AURenderCallbackStruct callback;
    AudioBufferList *bufferList;
    uint8_t *audioData;
    size_t audioBufferStride;
    UInt32 numberBuffers;
    UInt32 numberFrames;
    LC32SilentAudioRenderNotify *renderNotifySnapshot;
    size_t renderNotifySnapshotCapacity;
    LC32SilentAudioUnit *sourceMixer;
    AURenderCallbackStruct mixerCallbackSnapshot[
        LC32SilentAudioMaximumMixerBuses];
    AudioUnitParameterValue mixerLinearGainSnapshot[
        LC32SilentAudioMaximumMixerBuses];
    AudioUnitParameterValue mixerEnableSnapshot[
        LC32SilentAudioMaximumMixerBuses];
    UInt32 mixerInputBusCount;
    AudioBufferList mixerInputBufferList;
    uint8_t *mixerInputData;
    size_t mixerInputDataBytes;
    struct timespec interval;
} LC32SilentAudioPump;

enum {
    LC32SilentAudioUnitMagic = 0x4c415531, /* "LAU1" */
    LC32SilentAudioDefaultFrames = 512,
    LC32SilentAudioMaximumFrames = 4096,
    LC32SilentAudioMaximumChannels = 32,
    LC32SilentAudioMaximumBufferBytes = 16u * 1024u * 1024u,
};

static uint8_t LC32SilentRemoteIOComponent;
static uint8_t LC32SilentSpatialMixerComponent;
static uint32_t LC32PreferredIOBufferDurationBits;

_Static_assert(sizeof(AudioStreamBasicDescription) == 40,
    "ARM32 AudioStreamBasicDescription layout changed");
_Static_assert(sizeof(AURenderCallbackStruct) == 8,
    "ARM32 AURenderCallbackStruct layout changed");
_Static_assert(sizeof(LC32SilentAudioRenderNotify) == 8,
    "ARM32 render-notify tuple layout changed");
_Static_assert(sizeof(AudioUnitConnection) == 12,
    "ARM32 AudioUnitConnection layout changed");
_Static_assert(sizeof(AudioBuffer) == 12,
    "ARM32 AudioBuffer layout changed");
_Static_assert(offsetof(AudioBufferList, mBuffers) == 4 &&
               sizeof(AudioBufferList) == 16,
    "ARM32 AudioBufferList layout changed");

static LC32SilentAudioUnit *LC32SilentAudioUnitForHandle(AudioUnit unit) {
    LC32SilentAudioUnit *silent = (LC32SilentAudioUnit *)(uintptr_t)unit;
    return silent && silent->magic == LC32SilentAudioUnitMagic
        ? silent : NULL;
}

static void LC32SilentAudioRetain(LC32SilentAudioUnit *unit) {
    if(unit) {
        __atomic_add_fetch(&unit->referenceCount, 1, __ATOMIC_RELAXED);
    }
}

static void LC32SilentAudioRelease(LC32SilentAudioUnit *unit) {
    if(!unit || __atomic_sub_fetch(
            &unit->referenceCount, 1, __ATOMIC_ACQ_REL) != 0) {
        return;
    }
    unit->magic = 0;
    free(unit->renderNotifies);
    free(unit->propertyListeners);
    pthread_mutex_destroy(&unit->mutex);
    free(unit);
}

/* The output unit owns its graph source until it is disconnected or disposed.
 * This intentionally outlives AudioComponentInstanceDispose(mixer): PvZ
 * disposes its mixer before the still-connected RemoteIO instance. */
static LC32SilentAudioUnit *LC32SilentAudioDisconnectMixerLocked(
        LC32SilentAudioUnit *unit) {
    LC32SilentAudioUnit *mixer = unit->connectedMixer;
    unit->connectedMixer = NULL;
    return mixer;
}

static AudioStreamBasicDescription LC32SilentAudioCanonicalFormat(
        UInt32 channels) {
    return (AudioStreamBasicDescription){
        .mSampleRate = 44100.0,
        .mFormatID = kAudioFormatLinearPCM,
        .mFormatFlags = kAudioFormatFlagIsFloat |
            kAudioFormatFlagIsPacked |
            kAudioFormatFlagIsNonInterleaved,
        .mBytesPerPacket = sizeof(Float32),
        .mFramesPerPacket = 1,
        .mBytesPerFrame = sizeof(Float32),
        .mChannelsPerFrame = channels,
        .mBitsPerChannel = 8 * sizeof(Float32),
    };
}

static LC32SilentAudioUnit *LC32SilentAudioMixerForConnection(
        const AudioUnitConnection *connection) {
    if(!connection || connection->sourceOutputNumber != 0 ||
       connection->destInputNumber != 0) {
        return NULL;
    }
    LC32SilentAudioUnit *source = LC32SilentAudioUnitForHandle(
        connection->sourceAudioUnit);
    return source &&
            source->kind == LC32SilentAudioUnitKindSpatialMixer
        ? source : NULL;
}

static BOOL LC32SilentAudioFormatIsValid(
        const AudioStreamBasicDescription *format) {
    if(!format || format->mFormatID != kAudioFormatLinearPCM ||
       !(format->mSampleRate >= 1.0 && format->mSampleRate <= 384000.0) ||
       !format->mBytesPerFrame ||
       format->mBytesPerFrame > LC32SilentAudioMaximumBufferBytes ||
       !format->mChannelsPerFrame ||
       format->mChannelsPerFrame > LC32SilentAudioMaximumChannels) {
        return NO;
    }
    return YES;
}

static UInt32 LC32SilentAudioRenderFrames(
        const AudioStreamBasicDescription *format) {
    UInt32 durationBits = __atomic_load_n(
        &LC32PreferredIOBufferDurationBits, __ATOMIC_ACQUIRE);
    Float32 duration = 0;
    memcpy(&duration, &durationBits, sizeof(duration));
    const double requestedFrames = format->mSampleRate * (double)duration;
    if(requestedFrames >= 1.0 &&
       requestedFrames <= LC32SilentAudioMaximumFrames) {
        UInt32 frames = (UInt32)(requestedFrames + 0.5);
        return frames ? frames : 1;
    }
    return LC32SilentAudioDefaultFrames;
}

static void LC32SilentAudioResetBufferList(LC32SilentAudioPump *pump) {
    const BOOL nonInterleaved =
        (pump->format.mFormatFlags & kAudioFormatFlagIsNonInterleaved) != 0;
    const UInt32 channels = pump->format.mChannelsPerFrame;
    const UInt32 bytes = pump->numberFrames * pump->format.mBytesPerFrame;
    pump->bufferList->mNumberBuffers = pump->numberBuffers;
    for(UInt32 index = 0; index < pump->numberBuffers; ++index) {
        AudioBuffer *buffer = &pump->bufferList->mBuffers[index];
        buffer->mNumberChannels = nonInterleaved ? 1 : channels;
        buffer->mDataByteSize = bytes;
        buffer->mData = pump->audioData + pump->audioBufferStride * index;
        memset(buffer->mData, 0, bytes);
    }
}

static void LC32SilentAudioDestroyPump(LC32SilentAudioPump *pump) {
    if(!pump) return;
    free(pump->renderNotifySnapshot);
    free(pump->mixerInputData);
    free(pump->audioData);
    free(pump->bufferList);
    free(pump);
}

/* Take one callback-list snapshot for the entire render cycle. Callbacks may
 * add or remove notifications reentrantly; retaining this snapshot through
 * both phases gives every pre-render notification its matching post-render
 * notification without invoking guest code while holding the unit mutex. */
static size_t LC32SilentAudioSnapshotRenderNotifies(
        LC32SilentAudioPump *pump) {
    if(!pump || !pump->unit) return 0;

    pthread_mutex_lock(&pump->unit->mutex);
    const size_t count = pump->unit->renderNotifyCount;
    if(count > pump->renderNotifySnapshotCapacity) {
        if(count > SIZE_MAX / sizeof(*pump->renderNotifySnapshot)) {
            pthread_mutex_unlock(&pump->unit->mutex);
            return 0;
        }
        LC32SilentAudioRenderNotify *snapshot = realloc(
            pump->renderNotifySnapshot,
            count * sizeof(*pump->renderNotifySnapshot));
        if(!snapshot) {
            pthread_mutex_unlock(&pump->unit->mutex);
            return 0;
        }
        pump->renderNotifySnapshot = snapshot;
        pump->renderNotifySnapshotCapacity = count;
    }
    if(count) {
        memcpy(pump->renderNotifySnapshot, pump->unit->renderNotifies,
            count * sizeof(*pump->renderNotifySnapshot));
    }
    pthread_mutex_unlock(&pump->unit->mutex);
    return count;
}

static void LC32SilentAudioInvokeRenderNotifies(
        const LC32SilentAudioRenderNotify *notifies, size_t notifyCount,
        AudioUnitRenderActionFlags *actionFlags,
        AudioUnitRenderActionFlags phaseFlags,
        const AudioTimeStamp *timeStamp, UInt32 bus, UInt32 numberFrames,
        AudioBufferList *bufferList) {
    const AudioUnitRenderActionFlags phaseMask =
        kAudioUnitRenderAction_PreRender |
        kAudioUnitRenderAction_PostRender |
        kAudioUnitRenderAction_PostRenderError;
    for(size_t index = 0; index < notifyCount; ++index) {
        const LC32SilentAudioRenderNotify *notify = &notifies[index];
        if(!notify->proc) continue;
        *actionFlags = (*actionFlags & ~phaseMask) | phaseFlags;
        (void)notify->proc(notify->userData, actionFlags, timeStamp, bus,
            numberFrames, bufferList);
    }
}

/* Pull each active input bus of the lightweight spatial mixer. The legacy
 * mixer format is planar Float32: one mono buffer per input bus and two mono
 * buffers at its output. This is deliberately a basic gain-only mix; the
 * important compatibility behavior is that every guest render callback is
 * driven with the native bus number and buffer layout. */
static OSStatus LC32SilentAudioRenderMixer(
        LC32SilentAudioPump *pump,
        AudioUnitRenderActionFlags *actionFlags,
        const AudioTimeStamp *timeStamp) {
    LC32SilentAudioUnit *mixer = pump ? pump->sourceMixer : NULL;
    if(!mixer || !actionFlags || !timeStamp)
        return kAudio_ParamError;

    pthread_mutex_lock(&mixer->mutex);
    if(mixer->magic != LC32SilentAudioUnitMagic ||
       mixer->kind != LC32SilentAudioUnitKindSpatialMixer ||
       !mixer->initialized ||
       mixer->mixerInputBusCount > LC32SilentAudioMaximumMixerBuses) {
        pthread_mutex_unlock(&mixer->mutex);
        return kAudioUnitErr_Uninitialized;
    }
    pump->mixerInputBusCount = mixer->mixerInputBusCount;
    for(UInt32 bus = 0; bus < pump->mixerInputBusCount; ++bus) {
        pump->mixerCallbackSnapshot[bus] =
            mixer->mixerRenderCallbacks[bus];
        pump->mixerLinearGainSnapshot[bus] =
            mixer->mixerLinearGains[bus];
        pump->mixerEnableSnapshot[bus] =
            mixer->mixerParameters[bus][k3DMixerParam_Enable];
    }
    pthread_mutex_unlock(&mixer->mutex);

    if(pump->numberBuffers != 2 ||
       !(pump->format.mFormatFlags & kAudioFormatFlagIsFloat) ||
       !(pump->format.mFormatFlags & kAudioFormatFlagIsNonInterleaved) ||
       pump->format.mBytesPerFrame != sizeof(Float32) ||
       pump->format.mChannelsPerFrame != 2) {
        return kAudioUnitErr_FormatNotSupported;
    }

    Float32 *left = pump->bufferList->mBuffers[0].mData;
    Float32 *right = pump->bufferList->mBuffers[1].mData;
    if(!left || !right) return kAudio_ParamError;

    BOOL producedAudio = NO;
    OSStatus result = noErr;
    for(UInt32 bus = 0; bus < pump->mixerInputBusCount; ++bus) {
        const AURenderCallbackStruct callback =
            pump->mixerCallbackSnapshot[bus];
        if(!callback.inputProc || pump->mixerEnableSnapshot[bus] == 0.0f)
            continue;

        memset(pump->mixerInputData, 0, pump->mixerInputDataBytes);
        pump->mixerInputBufferList.mNumberBuffers = 1;
        pump->mixerInputBufferList.mBuffers[0] = (AudioBuffer){
            .mNumberChannels = 1,
            .mDataByteSize = (UInt32)pump->mixerInputDataBytes,
            .mData = pump->mixerInputData,
        };
        AudioUnitRenderActionFlags busFlags = 0;
        const OSStatus status = callback.inputProc(
            callback.inputProcRefCon, &busFlags, timeStamp, bus,
            pump->numberFrames, &pump->mixerInputBufferList);
        if(status != noErr) {
            if(result == noErr) result = status;
            continue;
        }
        if((busFlags & kAudioUnitRenderAction_OutputIsSilence) != 0)
            continue;
        if(pump->mixerInputBufferList.mNumberBuffers != 1 ||
           pump->mixerInputBufferList.mBuffers[0].mNumberChannels != 1 ||
           !pump->mixerInputBufferList.mBuffers[0].mData) {
            if(result == noErr) result = kAudio_ParamError;
            continue;
        }

        const UInt32 availableFrames =
            pump->mixerInputBufferList.mBuffers[0].mDataByteSize /
                sizeof(Float32);
        const UInt32 frames = availableFrames < pump->numberFrames
            ? availableFrames : pump->numberFrames;
        const Float32 *input =
            pump->mixerInputBufferList.mBuffers[0].mData;
        const Float32 gain = pump->mixerLinearGainSnapshot[bus];
        for(UInt32 frame = 0; frame < frames; ++frame) {
            const Float32 sample = input[frame] * gain;
            left[frame] += sample;
            right[frame] += sample;
        }
        producedAudio = producedAudio || frames != 0;
    }

    if(!producedAudio) {
        *actionFlags |= kAudioUnitRenderAction_OutputIsSilence;
    } else {
        for(UInt32 frame = 0; frame < pump->numberFrames; ++frame) {
            if(left[frame] > 1.0f) left[frame] = 1.0f;
            else if(left[frame] < -1.0f) left[frame] = -1.0f;
            if(right[frame] > 1.0f) right[frame] = 1.0f;
            else if(right[frame] < -1.0f) right[frame] = -1.0f;
        }
    }
    return result;
}

static void LC32SilentAudioApplyOutputVolume(
        LC32SilentAudioPump *pump,
        AudioUnitRenderActionFlags *actionFlags) {
    pthread_mutex_lock(&pump->unit->mutex);
    const Float32 volume = pump->unit->outputVolume;
    pthread_mutex_unlock(&pump->unit->mutex);
    if(volume == 1.0f) return;

    if(volume == 0.0f) {
        *actionFlags |= kAudioUnitRenderAction_OutputIsSilence;
    }
    if(!(pump->format.mFormatFlags & kAudioFormatFlagIsFloat) ||
       pump->format.mBitsPerChannel != 8 * sizeof(Float32)) {
        return;
    }
    for(UInt32 index = 0; index < pump->bufferList->mNumberBuffers;
            ++index) {
        AudioBuffer *buffer = &pump->bufferList->mBuffers[index];
        Float32 *samples = buffer->mData;
        const UInt32 sampleCount = buffer->mDataByteSize / sizeof(Float32);
        for(UInt32 sample = 0; samples && sample < sampleCount; ++sample) {
            Float32 value = samples[sample] * volume;
            if(value > 1.0f) value = 1.0f;
            else if(value < -1.0f) value = -1.0f;
            samples[sample] = value;
        }
    }
}

static LC32SilentAudioPump *LC32SilentAudioCreatePump(
        LC32SilentAudioUnit *unit) {
    if(!unit || unit->kind != LC32SilentAudioUnitKindRemoteIO ||
       !LC32SilentAudioFormatIsValid(&unit->format)) {
        return NULL;
    }

    LC32SilentAudioUnit *sourceMixer = unit->connectedMixer;
    if(!unit->renderCallback.inputProc && !sourceMixer) return NULL;

    LC32SilentAudioPump *pump = calloc(1, sizeof(*pump));
    if(!pump) return NULL;
    pump->unit = unit;
    pump->format = unit->format;
    pump->callback = unit->renderCallback;
    pump->sourceMixer = sourceMixer;
    pump->numberFrames = LC32SilentAudioRenderFrames(&pump->format);
    pump->numberBuffers =
        (pump->format.mFormatFlags & kAudioFormatFlagIsNonInterleaved)
        ? pump->format.mChannelsPerFrame : 1;

    if(pump->format.mBytesPerFrame >
       LC32SilentAudioMaximumBufferBytes / pump->numberFrames) {
        LC32SilentAudioDestroyPump(pump);
        return NULL;
    }
    const size_t bytes = (size_t)pump->numberFrames *
        pump->format.mBytesPerFrame;
    if(bytes > SIZE_MAX - 15u) {
        LC32SilentAudioDestroyPump(pump);
        return NULL;
    }
    pump->audioBufferStride = (bytes + 15u) & ~(size_t)15u;
    if(pump->numberBuffers >
       LC32SilentAudioMaximumBufferBytes / pump->audioBufferStride) {
        LC32SilentAudioDestroyPump(pump);
        return NULL;
    }

    const size_t listBytes = offsetof(AudioBufferList, mBuffers) +
        (size_t)pump->numberBuffers * sizeof(AudioBuffer);
    pump->bufferList = calloc(1, listBytes);
    pump->audioData = calloc(pump->numberBuffers,
        pump->audioBufferStride);
    if(!pump->bufferList || !pump->audioData) {
        LC32SilentAudioDestroyPump(pump);
        return NULL;
    }

    if(sourceMixer) {
        if(pump->numberFrames > SIZE_MAX / sizeof(Float32)) {
            LC32SilentAudioDestroyPump(pump);
            return NULL;
        }
        pump->mixerInputDataBytes =
            (size_t)pump->numberFrames * sizeof(Float32);
        pump->mixerInputData = calloc(1, pump->mixerInputDataBytes);
        if(!pump->mixerInputData) {
            LC32SilentAudioDestroyPump(pump);
            return NULL;
        }
    }

    const double seconds =
        (double)pump->numberFrames / pump->format.mSampleRate;
    pump->interval.tv_sec = (time_t)seconds;
    pump->interval.tv_nsec = (long)((seconds - pump->interval.tv_sec) *
        1000000000.0);
    if(pump->interval.tv_sec == 0 && pump->interval.tv_nsec < 1000000L)
        pump->interval.tv_nsec = 1000000L;
    LC32SilentAudioResetBufferList(pump);
    return pump;
}

static void *LC32SilentAudioPumpMain(void *context) {
    LC32SilentAudioPump *pump = context;
    Float64 sampleTime = 0;
    while(!__atomic_load_n(&pump->unit->stopRequested,
                           __ATOMIC_ACQUIRE)) {
        if(!__atomic_load_n(&pump->unit->started, __ATOMIC_ACQUIRE)) {
            const struct timespec idleInterval = {
                .tv_sec = 0,
                .tv_nsec = 1000000L,
            };
            (void)nanosleep(&idleInterval, NULL);
            continue;
        }
        LC32SilentAudioResetBufferList(pump);
        AudioUnitRenderActionFlags actionFlags = 0;
        AudioTimeStamp timeStamp = {0};
        timeStamp.mSampleTime = sampleTime;
        timeStamp.mFlags = kAudioTimeStampSampleTimeValid;
        const size_t notifyCount =
            LC32SilentAudioSnapshotRenderNotifies(pump);
        LC32SilentAudioInvokeRenderNotifies(
            pump->renderNotifySnapshot, notifyCount, &actionFlags,
            kAudioUnitRenderAction_PreRender, &timeStamp, 0,
            pump->numberFrames, pump->bufferList);
        actionFlags &= ~(kAudioUnitRenderAction_PreRender |
            kAudioUnitRenderAction_PostRender |
            kAudioUnitRenderAction_PostRenderError);
        const OSStatus renderStatus = pump->sourceMixer
            ? LC32SilentAudioRenderMixer(
                pump, &actionFlags, &timeStamp)
            : pump->callback.inputProc(
                pump->callback.inputProcRefCon,
                &actionFlags, &timeStamp, 0, pump->numberFrames,
                pump->bufferList);
        if(renderStatus == noErr) {
            LC32SilentAudioApplyOutputVolume(pump, &actionFlags);
        }
        AudioUnitRenderActionFlags postFlags =
            kAudioUnitRenderAction_PostRender;
        if(renderStatus != noErr)
            postFlags |= kAudioUnitRenderAction_PostRenderError;
        LC32SilentAudioInvokeRenderNotifies(
            pump->renderNotifySnapshot, notifyCount, &actionFlags,
            postFlags, &timeStamp, 0, pump->numberFrames,
            pump->bufferList);
        sampleTime += pump->numberFrames;

        BOOL hostPaced = NO;
        const uint32_t hostOutputToken = __atomic_load_n(
            &pump->unit->hostOutputToken, __ATOMIC_ACQUIRE);
        if(hostOutputToken && __atomic_load_n(
                &pump->unit->hostOutputHealthy, __ATOMIC_ACQUIRE)) {
            const BOOL silence = renderStatus != noErr ||
                (actionFlags & kAudioUnitRenderAction_OutputIsSilence) != 0;
            const OSStatus submitStatus = (OSStatus)LC32_AUDIO_CALL(
                LC32AudioToolboxOpRemoteIOOutputSubmit,
                LC32_AUDIO_U32(hostOutputToken),
                LC32_AUDIO_U32((uintptr_t)pump->bufferList),
                LC32_AUDIO_U32(pump->numberFrames),
                LC32_AUDIO_U32(silence));
            if(submitStatus == noErr) {
                /* Waiting for a returned native AudioQueue buffer supplies
                 * the pacing for the next render quantum. */
                hostPaced = YES;
            } else {
                __atomic_store_n(&pump->unit->hostOutputHealthy, 0,
                    __ATOMIC_RELEASE);
#if LC32_TRACE_AUDIO_OUTPUT
                fprintf(stderr,
                    "LC32: RemoteIO output submit failed: status=%d\n",
                    (int)submitStatus);
#endif
            }
        }
        if(hostPaced) continue;

        struct timespec remaining = pump->interval;
        while(!__atomic_load_n(&pump->unit->stopRequested,
                               __ATOMIC_ACQUIRE) &&
              nanosleep(&remaining, &remaining) != 0 && errno == EINTR) {}
    }
    LC32SilentAudioDestroyPump(pump);
    return NULL;
}

/* Allocate and create the first pump while initializing the AudioUnit. Tiny's
 * FMOD backend allocates its ring and starts its mixer only after Initialize
 * succeeds, so a resource failure here follows FMOD's safe early-unwind path.
 * The new thread remains idle until AudioOutputUnitStart publishes started. */
static OSStatus LC32SilentAudioPrepareThreadLocked(
        LC32SilentAudioUnit *unit) {
    LC32SilentAudioPump *pump = LC32SilentAudioCreatePump(unit);
    if(!pump) return kAudio_MemFullError;
    __atomic_store_n(&unit->stopRequested, 0, __ATOMIC_RELEASE);
    __atomic_store_n(&unit->started, 0, __ATOMIC_RELEASE);
    const int result = pthread_create(&unit->renderThread, NULL,
        LC32SilentAudioPumpMain, pump);
    if(result != 0) {
        __atomic_store_n(&unit->stopRequested, 1, __ATOMIC_RELEASE);
        LC32SilentAudioDestroyPump(pump);
        return kAudio_MemFullError;
    }
    unit->renderThreadJoinable = YES;
    unit->renderFrames = pump->numberFrames;
    return noErr;
}

/* Called and returned with unit->mutex held. Drop the mutex around join so a
 * callback already in flight may safely query/reenter the unit while Stop is
 * waiting for it. A competing lifecycle operation fails while this join owns
 * the thread; successful Stop/Uninitialize/Dispose calls still guarantee that
 * no callback can be executing after they return. */
static OSStatus LC32SilentAudioStopLocked(LC32SilentAudioUnit *unit) {
    if(unit->joiningRenderThread ||
       (unit->renderThreadJoinable &&
        pthread_equal(pthread_self(), unit->renderThread))) {
        return kAudioUnitErr_CannotDoInCurrentContext;
    }
    __atomic_store_n(&unit->started, 0, __ATOMIC_RELEASE);
    __atomic_store_n(&unit->stopRequested, 1, __ATOMIC_RELEASE);
    __atomic_store_n(&unit->hostOutputHealthy, 0, __ATOMIC_RELEASE);

    /* Retire the host token first. This marks the sink disposing and wakes a
     * render thread which may be blocked waiting for a returned native
     * AudioQueue buffer. The host keeps the in-flight submission alive until
     * it unwinds, so it is safe to join only after this cancellation. */
    const uint32_t hostOutputToken = __atomic_load_n(
        &unit->hostOutputToken, __ATOMIC_ACQUIRE);
    __atomic_store_n(&unit->hostOutputToken, 0, __ATOMIC_RELEASE);
    if(hostOutputToken) {
        const OSStatus outputStatus = (OSStatus)LC32_AUDIO_CALL(
            LC32AudioToolboxOpRemoteIOOutputStop,
            LC32_AUDIO_U32(hostOutputToken));
#if LC32_TRACE_AUDIO_OUTPUT
        if(outputStatus != noErr) {
            fprintf(stderr,
                "LC32: RemoteIO output stop failed: status=%d\n",
                (int)outputStatus);
        }
#else
        (void)outputStatus;
#endif
    }

    if(unit->renderThreadJoinable) {
        unit->joiningRenderThread = YES;
        const pthread_t renderThread = unit->renderThread;
        pthread_mutex_unlock(&unit->mutex);
        const int result = pthread_join(renderThread, NULL);
        pthread_mutex_lock(&unit->mutex);
        unit->joiningRenderThread = NO;
        if(result != 0) return kAudioUnitErr_CannotDoInCurrentContext;
        unit->renderThreadJoinable = NO;
    }
    return noErr;
}

AudioComponent AudioComponentFindNext(
        AudioComponent inComponent,
        const AudioComponentDescription *inDesc) {
    if(!inDesc) return NULL;
    const struct {
        AudioComponent component;
        OSType type;
        OSType subtype;
    } candidates[] = {
        {(AudioComponent)&LC32SilentRemoteIOComponent,
            kAudioUnitType_Output, kAudioUnitSubType_RemoteIO},
        {(AudioComponent)&LC32SilentSpatialMixerComponent,
            kAudioUnitType_Mixer, kAudioUnitSubType_SpatialMixer},
    };

    size_t first = 0;
    if(inComponent == candidates[0].component) first = 1;
    else if(inComponent == candidates[1].component) first = 2;
    else if(inComponent) return NULL;

    for(size_t index = first;
            index < sizeof(candidates) / sizeof(candidates[0]); ++index) {
        const BOOL typeMatches = !inDesc->componentType ||
            inDesc->componentType == candidates[index].type;
        const BOOL subtypeMatches = !inDesc->componentSubType ||
            inDesc->componentSubType == candidates[index].subtype;
        const BOOL manufacturerMatches =
            !inDesc->componentManufacturer ||
            inDesc->componentManufacturer == kAudioUnitManufacturer_Apple;
        const BOOL flagsMatch =
            (inDesc->componentFlags & inDesc->componentFlagsMask) == 0;
        if(typeMatches && subtypeMatches && manufacturerMatches &&
                flagsMatch) {
            return candidates[index].component;
        }
    }
    return NULL;
}

OSStatus AudioComponentInstanceNew(AudioComponent inComponent,
                                   AudioComponentInstance *outInstance) {
    if(outInstance) *outInstance = NULL;
    if(!outInstance ||
       (inComponent != (AudioComponent)&LC32SilentRemoteIOComponent &&
        inComponent != (AudioComponent)&LC32SilentSpatialMixerComponent)) {
        return kAudio_ParamError;
    }
    LC32SilentAudioUnit *silent = calloc(1, sizeof(*silent));
    if(!silent) return kAudio_MemFullError;
    if(pthread_mutex_init(&silent->mutex, NULL) != 0) {
        free(silent);
        return kAudio_MemFullError;
    }
    silent->magic = LC32SilentAudioUnitMagic;
    silent->referenceCount = 1;
    silent->kind =
        inComponent == (AudioComponent)&LC32SilentSpatialMixerComponent
        ? LC32SilentAudioUnitKindSpatialMixer
        : LC32SilentAudioUnitKindRemoteIO;
    silent->outputVolume = 1.0f;
    if(silent->kind == LC32SilentAudioUnitKindSpatialMixer) {
        silent->format = LC32SilentAudioCanonicalFormat(2);
        silent->mixerInputBusCount =
            LC32SilentAudioMaximumMixerBuses;
        for(UInt32 bus = 0;
                bus < LC32SilentAudioMaximumMixerBuses; ++bus) {
            silent->mixerInputFormats[bus] =
                LC32SilentAudioCanonicalFormat(1);
            silent->mixerLinearGains[bus] = 1.0f;
            silent->mixerParameters[bus][k3DMixerParam_PlaybackRate] =
                1.0f;
            silent->mixerParameters[bus][k3DMixerParam_Enable] = 1.0f;
        }
    } else {
        silent->format = LC32SilentAudioCanonicalFormat(2);
        silent->format.mSampleRate = 0;
    }
    *outInstance = (AudioComponentInstance)silent;
    return noErr;
}

OSStatus AudioComponentInstanceDispose(AudioComponentInstance inInstance) {
    LC32SilentAudioUnit *silent =
        LC32SilentAudioUnitForHandle((AudioUnit)inInstance);
    if(!silent) return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    if(silent->disposed) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudio_ParamError;
    }
    const OSStatus status = LC32SilentAudioStopLocked(silent);
    if(status != noErr) {
        pthread_mutex_unlock(&silent->mutex);
        return status;
    }
    silent->disposed = YES;
    LC32SilentAudioUnit *connectedMixer = NULL;
    if(silent->kind == LC32SilentAudioUnitKindRemoteIO) {
        connectedMixer = LC32SilentAudioDisconnectMixerLocked(silent);
    } else {
        silent->initialized = NO;
        memset(silent->mixerRenderCallbacks, 0,
            sizeof(silent->mixerRenderCallbacks));
    }
    pthread_mutex_unlock(&silent->mutex);
    LC32SilentAudioRelease(connectedMixer);
    LC32SilentAudioRelease(silent);
    return noErr;
}

static OSStatus LC32AudioUnitSetProperty(AudioUnit inUnit, AudioUnitPropertyID inID,
                              AudioUnitScope inScope,
                              AudioUnitElement inElement,
                              const void *inData, UInt32 inDataSize) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent || (inDataSize && !inData)) return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);

    if(silent->kind == LC32SilentAudioUnitKindRemoteIO) {
        if(inID == kAudioUnitProperty_StreamFormat &&
           inScope == kAudioUnitScope_Input && inElement == 0 &&
           inDataSize == sizeof(silent->format)) {
            if(silent->initialized || silent->renderThreadJoinable) {
                pthread_mutex_unlock(&silent->mutex);
                return kAudioUnitErr_Initialized;
            }
            memcpy(&silent->format, inData, sizeof(silent->format));
            LC32SilentAudioUnit *oldMixer =
                LC32SilentAudioDisconnectMixerLocked(silent);
            pthread_mutex_unlock(&silent->mutex);
            LC32SilentAudioRelease(oldMixer);
            return noErr;
        }
        if(inID == kAudioUnitProperty_SetRenderCallback &&
           inScope == kAudioUnitScope_Global && inElement == 0 &&
           inDataSize == sizeof(silent->renderCallback)) {
            if(silent->initialized || silent->renderThreadJoinable) {
                pthread_mutex_unlock(&silent->mutex);
                return kAudioUnitErr_Initialized;
            }
            memcpy(&silent->renderCallback, inData,
                sizeof(silent->renderCallback));
            LC32SilentAudioUnit *oldMixer =
                LC32SilentAudioDisconnectMixerLocked(silent);
            pthread_mutex_unlock(&silent->mutex);
            LC32SilentAudioRelease(oldMixer);
            return noErr;
        }
        if(inID == kAudioUnitProperty_MakeConnection &&
           inScope == kAudioUnitScope_Input && inElement == 0 &&
           inDataSize == sizeof(AudioUnitConnection)) {
            if(silent->initialized || silent->renderThreadJoinable) {
                pthread_mutex_unlock(&silent->mutex);
                return kAudioUnitErr_Initialized;
            }
            const AudioUnitConnection *connection = inData;
            if(!connection->sourceAudioUnit) {
                LC32SilentAudioUnit *oldMixer =
                    LC32SilentAudioDisconnectMixerLocked(silent);
                memset(&silent->renderCallback, 0,
                    sizeof(silent->renderCallback));
                silent->format = LC32SilentAudioCanonicalFormat(2);
                silent->format.mSampleRate = 0;
                pthread_mutex_unlock(&silent->mutex);
                LC32SilentAudioRelease(oldMixer);
                return noErr;
            }
            LC32SilentAudioUnit *mixer =
                LC32SilentAudioMixerForConnection(connection);
            if(!mixer) {
                pthread_mutex_unlock(&silent->mutex);
                return kAudioUnitErr_InvalidPropertyValue;
            }
            LC32SilentAudioRetain(mixer);
            pthread_mutex_lock(&mixer->mutex);
            if(mixer->disposed) {
                pthread_mutex_unlock(&mixer->mutex);
                pthread_mutex_unlock(&silent->mutex);
                LC32SilentAudioRelease(mixer);
                return kAudioUnitErr_InvalidPropertyValue;
            }
            const AudioStreamBasicDescription mixerFormat = mixer->format;
            pthread_mutex_unlock(&mixer->mutex);
            LC32SilentAudioUnit *oldMixer =
                LC32SilentAudioDisconnectMixerLocked(silent);
            silent->connectedMixer = mixer;
            memset(&silent->renderCallback, 0,
                sizeof(silent->renderCallback));
            silent->format = mixerFormat;
            pthread_mutex_unlock(&silent->mutex);
            LC32SilentAudioRelease(oldMixer);
            return noErr;
        }
    } else if(silent->kind ==
            LC32SilentAudioUnitKindSpatialMixer) {
        if(inID == kAudioUnitProperty_ElementCount &&
           inScope == kAudioUnitScope_Input && inElement == 0 &&
           inDataSize == sizeof(UInt32)) {
            if(silent->initialized) {
                pthread_mutex_unlock(&silent->mutex);
                return kAudioUnitErr_Initialized;
            }
            const UInt32 count = *(const UInt32 *)inData;
            if(!count || count > LC32SilentAudioMaximumMixerBuses) {
                pthread_mutex_unlock(&silent->mutex);
                return kAudioUnitErr_InvalidPropertyValue;
            }
            if(count < silent->mixerInputBusCount) {
                memset(&silent->mixerRenderCallbacks[count], 0,
                    (silent->mixerInputBusCount - count) *
                        sizeof(silent->mixerRenderCallbacks[0]));
            }
            silent->mixerInputBusCount = count;
            pthread_mutex_unlock(&silent->mutex);
            return noErr;
        }
        if(inID == kAudioUnitProperty_SetRenderCallback &&
           inScope == kAudioUnitScope_Input &&
           inElement < silent->mixerInputBusCount &&
           inDataSize == sizeof(AURenderCallbackStruct)) {
            memcpy(&silent->mixerRenderCallbacks[inElement], inData,
                sizeof(AURenderCallbackStruct));
            pthread_mutex_unlock(&silent->mutex);
            return noErr;
        }
    }
    pthread_mutex_unlock(&silent->mutex);
    return kAudioUnitErr_InvalidProperty;
}

OSStatus AudioUnitAddPropertyListener(AudioUnit unit, AudioUnitPropertyID property,
        AudioUnitPropertyListenerProc proc, void *userData) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(unit);
    if(!silent || !proc) return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    size_t count = silent->propertyListenerCount;
    if(silent->disposed || count == SIZE_MAX / sizeof(LC32AudioPropertyListener)) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudio_ParamError;
    }
    LC32AudioPropertyListener *listeners = realloc(silent->propertyListeners,
        (count + 1) * sizeof(*listeners));
    if(!listeners) { pthread_mutex_unlock(&silent->mutex); return kAudio_MemFullError; }
    listeners[count] = (LC32AudioPropertyListener){property, proc, userData};
    silent->propertyListeners = listeners;
    silent->propertyListenerCount = count + 1;
    pthread_mutex_unlock(&silent->mutex);
    return noErr;
}

static OSStatus LC32RemovePropertyListener(AudioUnit unit, AudioUnitPropertyID property,
        AudioUnitPropertyListenerProc proc, void *userData, BOOL matchUserData) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(unit);
    if(!silent || !proc) return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    size_t remaining = 0;
    for(size_t i = 0; i < silent->propertyListenerCount; ++i) {
        LC32AudioPropertyListener listener = silent->propertyListeners[i];
        if(listener.property != property || listener.proc != proc ||
           (matchUserData && listener.userData != userData))
            silent->propertyListeners[remaining++] = listener;
    }
    silent->propertyListenerCount = remaining;
    pthread_mutex_unlock(&silent->mutex);
    return noErr;
}

OSStatus AudioUnitRemovePropertyListener(AudioUnit unit, AudioUnitPropertyID property,
        AudioUnitPropertyListenerProc proc) {
    return LC32RemovePropertyListener(unit, property, proc, NULL, NO);
}

OSStatus AudioUnitRemovePropertyListenerWithUserData(AudioUnit unit,
        AudioUnitPropertyID property, AudioUnitPropertyListenerProc proc, void *userData) {
    return LC32RemovePropertyListener(unit, property, proc, userData, YES);
}

// Snapshot under the unit lock; guest callbacks may query properties, remove
// themselves, or dispose the unit. No native thread invokes ARM32 pointers.
static void LC32AudioNotifyProperty(LC32SilentAudioUnit *unit,
        AudioUnitPropertyID property, AudioUnitScope scope, AudioUnitElement element) {
    pthread_mutex_lock(&unit->mutex);
    size_t count = unit->propertyListenerCount;
    LC32AudioPropertyListener *snapshot = count ? malloc(count * sizeof(*snapshot)) : NULL;
    if(snapshot) memcpy(snapshot, unit->propertyListeners, count * sizeof(*snapshot));
    LC32SilentAudioRetain(unit);
    pthread_mutex_unlock(&unit->mutex);
    if(snapshot) {
        for(size_t i = 0; i < count; ++i) {
            pthread_mutex_lock(&unit->mutex);
            BOOL disposed = unit->disposed;
            pthread_mutex_unlock(&unit->mutex);
            if(disposed) break;
            if(snapshot[i].property == property)
                snapshot[i].proc(snapshot[i].userData, (AudioUnit)unit, property, scope, element);
        }
        free(snapshot);
    }
    LC32SilentAudioRelease(unit);
}

OSStatus AudioUnitSetProperty(AudioUnit unit, AudioUnitPropertyID property,
        AudioUnitScope scope, AudioUnitElement element, const void *data, UInt32 size) {
    OSStatus result = LC32AudioUnitSetProperty(unit, property, scope, element, data, size);
    if(result == noErr) LC32AudioNotifyProperty((LC32SilentAudioUnit *)unit, property, scope, element);
    return result;
}

OSStatus AudioUnitGetProperty(AudioUnit inUnit, AudioUnitPropertyID inID,
                              AudioUnitScope inScope,
                              AudioUnitElement inElement,
                              void *outData, UInt32 *ioDataSize) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent || !ioDataSize || (*ioDataSize && !outData))
        return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    if(inID == kAudioUnitProperty_MaximumFramesPerSlice &&
       inScope == kAudioUnitScope_Global && inElement == 0) {
        const UInt32 required = sizeof(UInt32);
        if(*ioDataSize < required) {
            *ioDataSize = required;
            pthread_mutex_unlock(&silent->mutex);
            return kAudio_ParamError;
        }
        *(UInt32 *)outData = LC32SilentAudioMaximumFrames;
        *ioDataSize = required;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }

    if(silent->kind == LC32SilentAudioUnitKindRemoteIO &&
       inID == kAudioOutputUnitProperty_IsRunning &&
       inScope == kAudioUnitScope_Global && inElement == 0) {
        const UInt32 required = sizeof(UInt32);
        if(*ioDataSize < required) {
            *ioDataSize = required;
            pthread_mutex_unlock(&silent->mutex);
            return kAudio_ParamError;
        }
        *(UInt32 *)outData = __atomic_load_n(
            &silent->started, __ATOMIC_ACQUIRE) != 0;
        *ioDataSize = required;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }

    if(silent->kind == LC32SilentAudioUnitKindRemoteIO &&
       inID == kAudioUnitProperty_StreamFormat && inElement == 0 &&
       (inScope == kAudioUnitScope_Input ||
        inScope == kAudioUnitScope_Output)) {
        const UInt32 required = sizeof(silent->format);
        if(*ioDataSize < required) {
            *ioDataSize = required;
            pthread_mutex_unlock(&silent->mutex);
            return kAudio_ParamError;
        }
        memcpy(outData, &silent->format, required);
        *ioDataSize = required;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }

    if(silent->kind == LC32SilentAudioUnitKindSpatialMixer &&
       inID == kAudioUnitProperty_ElementCount &&
       inScope == kAudioUnitScope_Input && inElement == 0) {
        const UInt32 required = sizeof(UInt32);
        if(*ioDataSize < required) {
            *ioDataSize = required;
            pthread_mutex_unlock(&silent->mutex);
            return kAudio_ParamError;
        }
        *(UInt32 *)outData = silent->mixerInputBusCount;
        *ioDataSize = required;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }

    if(silent->kind == LC32SilentAudioUnitKindSpatialMixer &&
       inID == kAudioUnitProperty_StreamFormat) {
        const AudioStreamBasicDescription *format = NULL;
        if(inScope == kAudioUnitScope_Input &&
                inElement < silent->mixerInputBusCount) {
            format = &silent->mixerInputFormats[inElement];
        } else if(inScope == kAudioUnitScope_Output && inElement == 0) {
            format = &silent->format;
        }
        if(format) {
            const UInt32 required = sizeof(*format);
            if(*ioDataSize < required) {
                *ioDataSize = required;
                pthread_mutex_unlock(&silent->mutex);
                return kAudio_ParamError;
            }
            memcpy(outData, format, required);
            *ioDataSize = required;
            pthread_mutex_unlock(&silent->mutex);
            return noErr;
        }
    }
    pthread_mutex_unlock(&silent->mutex);
    return kAudioUnitErr_InvalidProperty;
}

static BOOL LC32SilentAudioMixerParameterIsValid(
        AudioUnitParameterID parameter, AudioUnitParameterValue value) {
    if(!isfinite(value)) return NO;
    switch(parameter) {
        case k3DMixerParam_Azimuth:
            return value >= -180.0f && value <= 180.0f;
        case k3DMixerParam_Elevation:
            return value >= -90.0f && value <= 90.0f;
        case k3DMixerParam_Distance:
            return value >= 0.0f && value <= 10000.0f;
        case k3DMixerParam_Gain:
            return value >= -120.0f && value <= 20.0f;
        case k3DMixerParam_PlaybackRate:
            return value >= 0.5f && value <= 2.0f;
        case k3DMixerParam_Enable:
            return value >= 0.0f && value <= 1.0f;
    }
    return NO;
}

OSStatus AudioUnitSetParameter(AudioUnit inUnit,
                               AudioUnitParameterID inID,
                               AudioUnitScope inScope,
                               AudioUnitElement inElement,
                               AudioUnitParameterValue inValue,
                               UInt32 inBufferOffsetInFrames) {
    (void)inBufferOffsetInFrames;
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent) return kAudio_ParamError;

    pthread_mutex_lock(&silent->mutex);
    if(silent->kind == LC32SilentAudioUnitKindRemoteIO &&
       inID == kHALOutputParam_Volume &&
       inScope == kAudioUnitScope_Global && inElement == 0 &&
       isfinite(inValue) && inValue >= 0.0f && inValue <= 1.0f) {
        silent->outputVolume = inValue;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    if(silent->kind == LC32SilentAudioUnitKindSpatialMixer &&
       inScope == kAudioUnitScope_Input &&
       inElement < silent->mixerInputBusCount &&
       inID < LC32SilentAudioMixerParameterCount &&
       LC32SilentAudioMixerParameterIsValid(inID, inValue)) {
        silent->mixerParameters[inElement][inID] = inValue;
        if(inID == k3DMixerParam_Gain) {
            silent->mixerLinearGains[inElement] =
                powf(10.0f, inValue / 20.0f);
        }
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    pthread_mutex_unlock(&silent->mutex);
    return kAudioUnitErr_InvalidParameter;
}

OSStatus AudioUnitGetParameter(AudioUnit inUnit,
                               AudioUnitParameterID inID,
                               AudioUnitScope inScope,
                               AudioUnitElement inElement,
                               AudioUnitParameterValue *outValue) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent || !outValue) return kAudio_ParamError;

    pthread_mutex_lock(&silent->mutex);
    if(silent->kind == LC32SilentAudioUnitKindRemoteIO &&
       inID == kHALOutputParam_Volume &&
       inScope == kAudioUnitScope_Global && inElement == 0) {
        *outValue = silent->outputVolume;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    if(silent->kind == LC32SilentAudioUnitKindSpatialMixer &&
       inScope == kAudioUnitScope_Input &&
       inElement < silent->mixerInputBusCount &&
       inID < LC32SilentAudioMixerParameterCount) {
        *outValue = silent->mixerParameters[inElement][inID];
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    pthread_mutex_unlock(&silent->mutex);
    return kAudioUnitErr_InvalidParameter;
}

OSStatus AudioUnitAddRenderNotify(AudioUnit inUnit,
                                  AURenderCallback inProc,
                                  void *inProcUserData) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent || !inProc) return kAudio_ParamError;

    pthread_mutex_lock(&silent->mutex);
    if(silent->renderNotifyCount ==
            SIZE_MAX / sizeof(*silent->renderNotifies)) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudio_MemFullError;
    }
    const size_t newCount = silent->renderNotifyCount + 1;
    LC32SilentAudioRenderNotify *notifies = realloc(
        silent->renderNotifies, newCount * sizeof(*notifies));
    if(!notifies) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudio_MemFullError;
    }
    silent->renderNotifies = notifies;
    notifies[silent->renderNotifyCount] =
        (LC32SilentAudioRenderNotify){
            .proc = inProc,
            .userData = inProcUserData,
        };
    silent->renderNotifyCount = newCount;
    pthread_mutex_unlock(&silent->mutex);
    return noErr;
}

OSStatus AudioUnitRemoveRenderNotify(AudioUnit inUnit,
                                     AURenderCallback inProc,
                                     void *inProcUserData) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent || !inProc) return kAudio_ParamError;

    pthread_mutex_lock(&silent->mutex);
    size_t index = 0;
    while(index < silent->renderNotifyCount &&
          (silent->renderNotifies[index].proc != inProc ||
           silent->renderNotifies[index].userData != inProcUserData)) {
        ++index;
    }
    if(index == silent->renderNotifyCount) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudio_ParamError;
    }
    --silent->renderNotifyCount;
    if(index < silent->renderNotifyCount) {
        memmove(&silent->renderNotifies[index],
            &silent->renderNotifies[index + 1],
            (silent->renderNotifyCount - index) *
                sizeof(*silent->renderNotifies));
    }
    pthread_mutex_unlock(&silent->mutex);
    return noErr;
}

OSStatus AudioUnitInitialize(AudioUnit inUnit) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent) return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    if(silent->initialized) {
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    if(silent->kind == LC32SilentAudioUnitKindSpatialMixer) {
        silent->initialized = YES;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    if(silent->kind != LC32SilentAudioUnitKindRemoteIO ||
       (!silent->renderCallback.inputProc &&
        !silent->connectedMixer) ||
       !LC32SilentAudioFormatIsValid(&silent->format)) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudioUnitErr_InvalidPropertyValue;
    }
    const OSStatus status = LC32SilentAudioPrepareThreadLocked(silent);
    if(status != noErr) {
        pthread_mutex_unlock(&silent->mutex);
        return status;
    }
    silent->initialized = YES;
    pthread_mutex_unlock(&silent->mutex);
    return noErr;
}

OSStatus AudioUnitUninitialize(AudioUnit inUnit) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(inUnit);
    if(!silent) return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    if(silent->kind == LC32SilentAudioUnitKindSpatialMixer) {
        silent->initialized = NO;
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    BOOL wasRunning = __atomic_load_n(&silent->started, __ATOMIC_ACQUIRE) != 0;
    const OSStatus status = LC32SilentAudioStopLocked(silent);
    if(status != noErr) {
        pthread_mutex_unlock(&silent->mutex);
        return status;
    }
    silent->initialized = NO;
    pthread_mutex_unlock(&silent->mutex);
    if(wasRunning)
        LC32AudioNotifyProperty(silent, kAudioOutputUnitProperty_IsRunning, kAudioUnitScope_Global, 0);
    return noErr;
}

OSStatus AudioOutputUnitStart(AudioUnit ci) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(ci);
    if(!silent || silent->kind != LC32SilentAudioUnitKindRemoteIO)
        return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    if(!silent->initialized) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudioUnitErr_Uninitialized;
    }
    if(__atomic_load_n(&silent->started, __ATOMIC_ACQUIRE)) {
        pthread_mutex_unlock(&silent->mutex);
        return noErr;
    }
    if(silent->joiningRenderThread) {
        pthread_mutex_unlock(&silent->mutex);
        return kAudioUnitErr_CannotDoInCurrentContext;
    }
    if(!silent->renderThreadJoinable) {
        const OSStatus status = LC32SilentAudioPrepareThreadLocked(silent);
        if(status != noErr) {
            pthread_mutex_unlock(&silent->mutex);
            return status;
        }
    }

    uint32_t hostOutputToken = 0;
    const OSStatus outputStatus = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpRemoteIOOutputStart,
        LC32_AUDIO_U32((uintptr_t)&silent->format),
        LC32_AUDIO_U32(silent->renderFrames),
        LC32_AUDIO_U32((uintptr_t)&hostOutputToken));
    if(outputStatus == noErr && hostOutputToken) {
        __atomic_store_n(&silent->hostOutputToken, hostOutputToken,
            __ATOMIC_RELEASE);
        __atomic_store_n(&silent->hostOutputHealthy, 1,
            __ATOMIC_RELEASE);
#if LC32_TRACE_AUDIO_OUTPUT
        fprintf(stderr,
            "LC32: RemoteIO host output started: token=0x%x frames=%u\n",
            hostOutputToken, silent->renderFrames);
#endif
    } else {
        /* Native Simulator audio can be unavailable (for example status
         * -66628 with no route). Preserve the compatibility pump so FMOD's
         * mixer and game-side timing continue even when output is silent. */
        if(hostOutputToken) {
            (void)LC32_AUDIO_CALL(LC32AudioToolboxOpRemoteIOOutputStop,
                LC32_AUDIO_U32(hostOutputToken));
        }
        __atomic_store_n(&silent->hostOutputToken, 0, __ATOMIC_RELEASE);
        __atomic_store_n(&silent->hostOutputHealthy, 0,
            __ATOMIC_RELEASE);
#if LC32_TRACE_AUDIO_OUTPUT
        fprintf(stderr,
            "LC32: RemoteIO host output unavailable; using silent pacing "
            "(status=%d token=0x%x)\n", (int)outputStatus,
            hostOutputToken);
#endif
    }
    __atomic_store_n(&silent->started, 1, __ATOMIC_RELEASE);
    pthread_mutex_unlock(&silent->mutex);
    LC32AudioNotifyProperty(silent, kAudioOutputUnitProperty_IsRunning, kAudioUnitScope_Global, 0);
    return noErr;
}

OSStatus AudioOutputUnitStop(AudioUnit ci) {
    LC32SilentAudioUnit *silent = LC32SilentAudioUnitForHandle(ci);
    if(!silent || silent->kind != LC32SilentAudioUnitKindRemoteIO)
        return kAudio_ParamError;
    pthread_mutex_lock(&silent->mutex);
    BOOL wasRunning = __atomic_load_n(&silent->started, __ATOMIC_ACQUIRE) != 0;
    const OSStatus status = LC32SilentAudioStopLocked(silent);
    pthread_mutex_unlock(&silent->mutex);
    if(status == noErr && wasRunning)
        LC32AudioNotifyProperty(silent, kAudioOutputUnitProperty_IsRunning, kAudioUnitScope_Global, 0);
    return status;
}

OSStatus AudioUnitRender(AudioUnit inUnit,
                         AudioUnitRenderActionFlags *ioActionFlags,
                         const AudioTimeStamp *inTimeStamp,
                         UInt32 inOutputBusNumber,
                         UInt32 inNumberFrames,
                         AudioBufferList *ioData) {
    (void)ioActionFlags;
    (void)inTimeStamp;
    (void)inOutputBusNumber;
    (void)inNumberFrames;
    if(!LC32SilentAudioUnitForHandle(inUnit) || !ioData ||
            ioData->mNumberBuffers > 64) {
        return kAudio_ParamError;
    }
    for(UInt32 index = 0; index < ioData->mNumberBuffers; ++index) {
        AudioBuffer *buffer = &ioData->mBuffers[index];
        if(buffer->mData && buffer->mDataByteSize)
            memset(buffer->mData, 0, buffer->mDataByteSize);
    }
    return noErr;
}

OSStatus AudioConverterNew(
        const AudioStreamBasicDescription *inSourceFormat,
        const AudioStreamBasicDescription *inDestinationFormat,
        AudioConverterRef *outAudioConverter) {
    if(!outAudioConverter) return kAudio_ParamError;
    *outAudioConverter = NULL;
    if(!inSourceFormat || !inDestinationFormat)
        return kAudio_ParamError;
    uint32_t token = 0;
    const OSStatus status = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioConverterNew,
        LC32_AUDIO_U32((uintptr_t)inSourceFormat),
        LC32_AUDIO_U32((uintptr_t)inDestinationFormat),
        LC32_AUDIO_U32((uintptr_t)&token));
    if(status == noErr && token)
        *outAudioConverter = (AudioConverterRef)(uintptr_t)token;
    return status;
}

OSStatus AudioConverterDispose(AudioConverterRef inAudioConverter) {
    if(!inAudioConverter) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioConverterDispose,
        LC32_AUDIO_U32((uintptr_t)inAudioConverter));
}

OSStatus AudioConverterReset(AudioConverterRef inAudioConverter) {
    if(!inAudioConverter) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioConverterReset,
        LC32_AUDIO_U32((uintptr_t)inAudioConverter));
}

OSStatus AudioConverterFillComplexBuffer(
        AudioConverterRef inAudioConverter,
        AudioConverterComplexInputDataProc inInputDataProc,
        void *inInputDataProcUserData,
        UInt32 *ioOutputDataPacketSize,
        AudioBufferList *outOutputData,
        AudioStreamPacketDescription *outPacketDescription) {
    if(!inAudioConverter || !inInputDataProc ||
       !ioOutputDataPacketSize || !outOutputData) {
        return kAudio_ParamError;
    }
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioConverterFillComplexBuffer,
        LC32_AUDIO_U32((uintptr_t)inAudioConverter),
        LC32_AUDIO_U32((uintptr_t)inInputDataProc),
        LC32_AUDIO_U32((uintptr_t)inInputDataProcUserData),
        LC32_AUDIO_U32((uintptr_t)ioOutputDataPacketSize),
        LC32_AUDIO_U32((uintptr_t)outOutputData),
        LC32_AUDIO_U32((uintptr_t)outPacketDescription));
}

OSStatus AudioQueueFlush(AudioQueueRef inAQ) {
    if(!inAQ) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(LC32AudioToolboxOpAudioQueueFlush,
        LC32_AUDIO_U32((uintptr_t)inAQ));
}

OSStatus AudioQueueReset(AudioQueueRef inAQ) {
    if(!inAQ) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(LC32AudioToolboxOpAudioQueueReset,
        LC32_AUDIO_U32((uintptr_t)inAQ));
}

OSStatus AudioQueueSetOfflineRenderFormat(
        AudioQueueRef inAQ,
        const AudioStreamBasicDescription *inFormat,
        const AudioChannelLayout *inLayout) {
    if(!inAQ) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueSetOfflineRenderFormat,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inFormat),
        LC32_AUDIO_U32((uintptr_t)inLayout));
}

OSStatus AudioQueueOfflineRender(AudioQueueRef inAQ,
                                 const AudioTimeStamp *inTimestamp,
                                 AudioQueueBufferRef ioBuffer,
                                 UInt32 inNumberFrames) {
    if(!inAQ || !ioBuffer || !inTimestamp) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueOfflineRender,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inTimestamp),
        LC32_AUDIO_U32((uintptr_t)ioBuffer), LC32_AUDIO_U32(inNumberFrames));
}

// TODO: remaining AudioServices forwarding

OSStatus AudioServicesAddSystemSoundCompletion(
        SystemSoundID inSystemSoundID, CFRunLoopRef inRunLoop,
        CFStringRef inRunLoopMode,
        AudioServicesSystemSoundCompletionProc inCompletionRoutine,
        void *inClientData) {
    (void)inSystemSoundID;
    (void)inRunLoop;
    (void)inRunLoopMode;
    (void)inCompletionRoutine;
    (void)inClientData;
    return noErr;
}

void AudioServicesRemoveSystemSoundCompletion(SystemSoundID inSystemSoundID) {
    (void)inSystemSoundID;
}

OSStatus AudioServicesCreateSystemSoundID(CFURLRef inFileURL, SystemSoundID *outSystemSoundID) {
    //static hostAddr = host_dlsym("AudioServicesCreateSystemSoundID");
    return 0;
}

OSStatus AudioServicesDisposeSystemSoundID(SystemSoundID inSystemSoundID) {
    return 0;
}

void AudioServicesPlaySystemSound(SystemSoundID inSystemSoundID) {
    
}

OSStatus AudioQueueAddPropertyListener(AudioQueueRef inAQ, AudioQueuePropertyID inID, AudioQueuePropertyListenerProc inProc, void * inUserData) {
    if(!inAQ || !inProc) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueAddPropertyListener,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inID),
        LC32_AUDIO_U32((uintptr_t)inProc),
        LC32_AUDIO_U32((uintptr_t)&LC32AudioQueueInvokePropertyListener),
        LC32_AUDIO_U32((uintptr_t)inUserData));
}

OSStatus AudioServicesSetProperty(AudioServicesPropertyID inPropertyID, UInt32 inSpecifierSize, const void * inSpecifier, UInt32 inPropertyDataSize, const void * inPropertyData) {
    return 0;
}

OSStatus AudioQueueAllocateBuffer(AudioQueueRef inAQ, UInt32 inBufferByteSize, AudioQueueBufferRef * outBuffer) {
    return AudioQueueAllocateBufferWithPacketDescriptions(
        inAQ, inBufferByteSize, 0, outBuffer);
}

OSStatus AudioQueueAllocateBufferWithPacketDescriptions(
        AudioQueueRef inAQ, UInt32 inBufferByteSize,
        UInt32 inNumberPacketDescriptions,
        AudioQueueBufferRef *outBuffer) {
    if(outBuffer) *outBuffer = NULL;
    if(!inAQ || !outBuffer) return kAudio_ParamError;
    if(inBufferByteSize > LC32AudioQueueMaximumAllocationBytes)
        return kAudio_ParamError;
    if(inNumberPacketDescriptions >
            SIZE_MAX / sizeof(AudioStreamPacketDescription)) {
        return kAudio_ParamError;
    }

    const size_t packetBytes = (size_t)inNumberPacketDescriptions *
        sizeof(AudioStreamPacketDescription);
    if(packetBytes > LC32AudioQueueMaximumAllocationBytes)
        return kAudio_ParamError;
    if(sizeof(LC32GuestAudioQueueAllocation) > SIZE_MAX - 7u)
        return kAudio_ParamError;
    const size_t dataOffset = LC32AudioQueueAlign8(
        sizeof(LC32GuestAudioQueueAllocation));
    if((size_t)inBufferByteSize > SIZE_MAX - dataOffset)
        return kAudio_ParamError;
    const size_t unalignedPacketOffset =
        dataOffset + (size_t)inBufferByteSize;
    if(unalignedPacketOffset > SIZE_MAX - 7u) return kAudio_ParamError;
    const size_t packetOffset =
        LC32AudioQueueAlign8(unalignedPacketOffset);
    if(packetOffset > LC32AudioQueueMaximumAllocationBytes ||
       packetBytes > LC32AudioQueueMaximumAllocationBytes - packetOffset) {
        return kAudio_ParamError;
    }

    LC32GuestAudioQueueAllocation *allocation =
        calloc(1, packetOffset + packetBytes);
    if(!allocation) return kAudio_MemFullError;
    allocation->queue = inAQ;
    allocation->buffer.audioDataBytesCapacity = inBufferByteSize;
    allocation->buffer.audioData =
        (uint32_t)(uintptr_t)((uint8_t *)allocation + dataOffset);
    allocation->buffer.packetDescriptionCapacity =
        inNumberPacketDescriptions;
    allocation->buffer.packetDescriptions = inNumberPacketDescriptions
        ? (uint32_t)(uintptr_t)((uint8_t *)allocation + packetOffset) : 0;
    allocation->callbackStorage.packetDescriptions =
        allocation->buffer.packetDescriptions;

    LC32GuestAudioQueueLifecycle *lifecycle =
        LC32AudioQueueAcquireLifecycle(inAQ);
    if(!lifecycle) {
        free(allocation);
        return kAudio_ParamError;
    }

    OSStatus status = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueAllocateBuffer,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inBufferByteSize),
        LC32_AUDIO_U32(inNumberPacketDescriptions),
        LC32_AUDIO_U32((uintptr_t)&allocation->buffer),
        LC32_AUDIO_U32(allocation->buffer.audioData),
        LC32_AUDIO_U32(allocation->buffer.packetDescriptions),
        LC32_AUDIO_U32((uintptr_t)&allocation->callbackStorage));
    if(status != noErr) {
        LC32AudioQueueReleaseLifecycle(lifecycle);
        free(allocation);
        return status;
    }
    LC32AudioQueueTrackAllocation(allocation);
    *outBuffer = (AudioQueueBufferRef)&allocation->buffer;
    LC32AudioQueueReleaseLifecycle(lifecycle);
    return noErr;
}

OSStatus AudioQueueDispose(AudioQueueRef inAQ, Boolean inImmediate) {
    if(!inAQ) return kAudio_ParamError;
    LC32GuestAudioQueueLifecycle *lifecycle =
        LC32AudioQueueAcquireLifecycle(inAQ);
    if(!lifecycle) return kAudio_ParamError;

    /* Do not hold this mutex while a control thread waits for a callback to
     * leave the native queue. A callback is allowed to reenter AudioQueue APIs;
     * mark the lifecycle first so those calls fail instead of deadlocking on
     * the disposing thread. Keep the users reference until the result has been
     * applied so the lifecycle itself cannot disappear while unlocked. */
    lifecycle->disposing = YES;
    pthread_mutex_unlock(&lifecycle->mutex);

    uint32_t terminal = 0;
    OSStatus status = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueDispose,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inImmediate),
        LC32_AUDIO_U32((uintptr_t)&terminal),
        LC32_AUDIO_U32((uintptr_t)
            &LC32AudioQueueReleaseDeferredAllocations));

    pthread_mutex_lock(&lifecycle->mutex);
    if(terminal != LC32AudioQueueDisposeTerminalNone) {
        if(terminal == LC32AudioQueueDisposeTerminalReleaseMirrors)
            LC32AudioQueueReleaseAllocations(inAQ);
        LC32AudioQueueRemoveLifecycleLocked(lifecycle);
    } else {
        lifecycle->disposing = NO;
    }
    LC32AudioQueueReleaseLifecycle(lifecycle);
    return status;
}

OSStatus AudioQueueEnqueueBuffer(AudioQueueRef inAQ, AudioQueueBufferRef inBuffer, UInt32 inNumPacketDescs, const AudioStreamPacketDescription * inPacketDescs) {
    if(!inAQ || !inBuffer || (inNumPacketDescs && !inPacketDescs))
        return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueEnqueueBuffer,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inBuffer),
        LC32_AUDIO_U32(inNumPacketDescs),
        LC32_AUDIO_U32((uintptr_t)inPacketDescs));
}

OSStatus AudioQueueFreeBuffer(AudioQueueRef inAQ, AudioQueueBufferRef inBuffer) {
    if(!inAQ || !inBuffer) return kAudio_ParamError;
    pthread_mutex_lock(&LC32AudioQueueAllocationsMutex);
    LC32GuestAudioQueueAllocation **cursor = &LC32AudioQueueAllocations;
    while(*cursor && ((AudioQueueBufferRef)&(*cursor)->buffer != inBuffer ||
            (*cursor)->queue != inAQ)) {
        cursor = &(*cursor)->next;
    }
    LC32GuestAudioQueueAllocation *allocation = *cursor;
    if(!allocation) {
        pthread_mutex_unlock(&LC32AudioQueueAllocationsMutex);
        return kAudioQueueErr_InvalidBuffer;
    }
    OSStatus status = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueFreeBuffer,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inBuffer));
    if(status == noErr) {
        *cursor = allocation->next;
        pthread_mutex_unlock(&LC32AudioQueueAllocationsMutex);
        free(allocation);
    } else {
        pthread_mutex_unlock(&LC32AudioQueueAllocationsMutex);
    }
    return status;
}

OSStatus AudioQueueGetProperty(AudioQueueRef inAQ, AudioQueuePropertyID inID, void * outData, UInt32 * ioDataSize) {
    if(!inAQ || !ioDataSize || (*ioDataSize && !outData))
        return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueGetProperty,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inID),
        LC32_AUDIO_U32((uintptr_t)outData),
        LC32_AUDIO_U32((uintptr_t)ioDataSize));
}

OSStatus AudioQueueGetPropertySize(AudioQueueRef inAQ,
        AudioQueuePropertyID inID, UInt32 *outDataSize) {
    if(!inAQ || !outDataSize) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueGetPropertySize,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inID),
        LC32_AUDIO_U32((uintptr_t)outDataSize));
}

OSStatus AudioQueueNewInput(const AudioStreamBasicDescription * inFormat, AudioQueueInputCallback inCallbackProc, void * inUserData, CFRunLoopRef inCallbackRunLoop, CFStringRef inCallbackRunLoopMode, UInt32 inFlags, AudioQueueRef * outAQ) {
    if(outAQ) *outAQ = NULL;
    if(!inFormat || !inCallbackProc || !outAQ) return kAudio_ParamError;
    AudioQueueRef queue = NULL;
    OSStatus status = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueNewInput,
        LC32_AUDIO_U32((uintptr_t)inFormat),
        LC32_AUDIO_U32((uintptr_t)inCallbackProc),
        LC32_AUDIO_U32((uintptr_t)&LC32AudioQueueInvokeInputCallback),
        LC32_AUDIO_U32((uintptr_t)inUserData),
        inCallbackRunLoop ? [(id)inCallbackRunLoop host_self] : 0,
        inCallbackRunLoopMode ? [(id)inCallbackRunLoopMode host_self] : 0,
        LC32_AUDIO_U32(inFlags),
        LC32_AUDIO_U32((uintptr_t)&queue));
    if(status != noErr) return status;
    if(!queue || !LC32AudioQueueCreateLifecycle(queue)) {
        uint32_t terminal = 0;
        (void)LC32_AUDIO_CALL(LC32AudioToolboxOpAudioQueueDispose,
            LC32_AUDIO_U32((uintptr_t)queue), LC32_AUDIO_U32(YES),
            LC32_AUDIO_U32((uintptr_t)&terminal),
            LC32_AUDIO_U32((uintptr_t)
                &LC32AudioQueueReleaseDeferredAllocations));
        return kAudio_MemFullError;
    }
    *outAQ = queue;
    return noErr;
}

OSStatus AudioQueueNewOutput(
        const AudioStreamBasicDescription *inFormat,
        AudioQueueOutputCallback inCallbackProc, void *inUserData,
        CFRunLoopRef inCallbackRunLoop,
        CFStringRef inCallbackRunLoopMode, UInt32 inFlags,
        AudioQueueRef *outAQ) {
    if(outAQ) *outAQ = NULL;
    if(!inFormat || !inCallbackProc || !outAQ) return kAudio_ParamError;
    AudioQueueRef queue = NULL;
    OSStatus status = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueNewOutput,
        LC32_AUDIO_U32((uintptr_t)inFormat),
        LC32_AUDIO_U32((uintptr_t)inCallbackProc),
        LC32_AUDIO_U32((uintptr_t)&LC32AudioQueueInvokeOutputCallback),
        LC32_AUDIO_U32((uintptr_t)inUserData),
        inCallbackRunLoop ? [(id)inCallbackRunLoop host_self] : 0,
        inCallbackRunLoopMode ? [(id)inCallbackRunLoopMode host_self] : 0,
        LC32_AUDIO_U32(inFlags),
        LC32_AUDIO_U32((uintptr_t)&queue));
    if(status != noErr) return status;
    if(!queue || !LC32AudioQueueCreateLifecycle(queue)) {
        uint32_t terminal = 0;
        (void)LC32_AUDIO_CALL(LC32AudioToolboxOpAudioQueueDispose,
            LC32_AUDIO_U32((uintptr_t)queue), LC32_AUDIO_U32(YES),
            LC32_AUDIO_U32((uintptr_t)&terminal),
            LC32_AUDIO_U32((uintptr_t)
                &LC32AudioQueueReleaseDeferredAllocations));
        return kAudio_MemFullError;
    }
    *outAQ = queue;
    return noErr;
}

OSStatus AudioQueuePause(AudioQueueRef inAQ) {
    if(!inAQ) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueuePause,
        LC32_AUDIO_U32((uintptr_t)inAQ));
}

OSStatus AudioQueueSetProperty(AudioQueueRef inAQ, AudioQueuePropertyID inID, const void * inData, UInt32 inDataSize) {
    if(!inAQ || (inDataSize && !inData)) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueSetProperty,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inID),
        LC32_AUDIO_U32((uintptr_t)inData), LC32_AUDIO_U32(inDataSize));
}

OSStatus AudioQueueStart(AudioQueueRef inAQ, const AudioTimeStamp * inStartTime) {
    if(!inAQ) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueStart,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inStartTime));
}

OSStatus AudioQueueStop(AudioQueueRef inAQ, Boolean inImmediate) {
    if(!inAQ) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueStop,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inImmediate));
}

OSStatus AudioQueueDeviceGetCurrentTime(
        AudioQueueRef inAQ, AudioTimeStamp *outTimeStamp) {
    if(outTimeStamp) memset(outTimeStamp, 0, sizeof(*outTimeStamp));
    if(!inAQ || !outTimeStamp) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueDeviceGetCurrentTime,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)outTimeStamp));
}

OSStatus AudioQueueCreateTimeline(AudioQueueRef inAQ,
                                  AudioQueueTimelineRef *outTimeline) {
    if(outTimeline) *outTimeline = NULL;
    if(!inAQ || !outTimeline) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueCreateTimeline,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)outTimeline));
}

OSStatus AudioQueueDeviceTranslateTime(AudioQueueRef inAQ,
        const AudioTimeStamp *inTime, AudioTimeStamp *outTime) {
    if(!inAQ || !inTime || !outTime) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueDeviceTranslateTime,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inTime),
        LC32_AUDIO_U32((uintptr_t)outTime));
}

OSStatus AudioQueueDeviceGetNearestStartTime(AudioQueueRef inAQ,
        AudioTimeStamp *ioRequestedStartTime, UInt32 inFlags) {
    if(!inAQ || !ioRequestedStartTime) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueDeviceGetNearestStartTime,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)ioRequestedStartTime),
        LC32_AUDIO_U32(inFlags));
}

OSStatus AudioQueueDisposeTimeline(AudioQueueRef inAQ,
                                   AudioQueueTimelineRef inTimeline) {
    if(!inAQ || !inTimeline) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueDisposeTimeline,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inTimeline));
}

OSStatus AudioQueueGetCurrentTime(
        AudioQueueRef inAQ, AudioQueueTimelineRef inTimeline,
        AudioTimeStamp *outTimeStamp,
        Boolean *outTimelineDiscontinuity) {
    if(outTimeStamp) memset(outTimeStamp, 0, sizeof(*outTimeStamp));
    if(outTimelineDiscontinuity) *outTimelineDiscontinuity = false;
    if(!inAQ || (!outTimeStamp && !outTimelineDiscontinuity))
        return kAudio_ParamError;
    if(!inTimeline && outTimelineDiscontinuity)
        return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueGetCurrentTime,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inTimeline),
        LC32_AUDIO_U32((uintptr_t)outTimeStamp),
        LC32_AUDIO_U32((uintptr_t)outTimelineDiscontinuity));
}

OSStatus AudioQueueEnqueueBufferWithParameters(
        AudioQueueRef inAQ, AudioQueueBufferRef inBuffer,
        UInt32 inNumPacketDescs,
        const AudioStreamPacketDescription *inPacketDescs,
        UInt32 inTrimFramesAtStart, UInt32 inTrimFramesAtEnd,
        UInt32 inNumParamValues,
        const AudioQueueParameterEvent *inParamValues,
        const AudioTimeStamp *inStartTime,
        AudioTimeStamp *outActualStartTime) {
    if(!inAQ || !inBuffer || (inNumParamValues && !inParamValues))
        return kAudio_ParamError;
    const LC32AudioQueueEnqueueParameters parameters = {
        inTrimFramesAtStart, inTrimFramesAtEnd, inNumParamValues,
        (uint32_t)(uintptr_t)inParamValues, (uint32_t)(uintptr_t)inStartTime,
        (uint32_t)(uintptr_t)outActualStartTime,
    };
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueEnqueueBufferWithParameters,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32((uintptr_t)inBuffer), LC32_AUDIO_U32(inNumPacketDescs),
        LC32_AUDIO_U32((uintptr_t)inPacketDescs),
        LC32_AUDIO_U32((uintptr_t)&parameters));
}

OSStatus AudioQueuePrime(AudioQueueRef inAQ,
                         UInt32 inNumberOfFramesToPrepare,
                         UInt32 *outNumberOfFramesPrepared) {
    if(outNumberOfFramesPrepared) *outNumberOfFramesPrepared = 0;
    if(!inAQ) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueuePrime,
        LC32_AUDIO_U32((uintptr_t)inAQ),
        LC32_AUDIO_U32(inNumberOfFramesToPrepare),
        LC32_AUDIO_U32((uintptr_t)outNumberOfFramesPrepared));
}

OSStatus AudioQueueRemovePropertyListener(
        AudioQueueRef inAQ, AudioQueuePropertyID inID,
        AudioQueuePropertyListenerProc inProc, void *inUserData) {
    if(!inAQ || !inProc) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueRemovePropertyListener,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inID),
        LC32_AUDIO_U32((uintptr_t)inProc),
        LC32_AUDIO_U32((uintptr_t)inUserData));
}

OSStatus AudioQueueSetParameter(AudioQueueRef inAQ,
                                AudioQueueParameterID inParamID,
                                AudioQueueParameterValue inValue) {
    if(!inAQ) return kAudio_ParamError;
    union {
        AudioQueueParameterValue value;
        uint32_t bits;
    } representation = { .value = inValue };
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueSetParameter,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inParamID),
        LC32_AUDIO_U32(representation.bits));
}

OSStatus AudioQueueGetParameter(AudioQueueRef inAQ,
        AudioQueueParameterID inParamID, AudioQueueParameterValue *outValue) {
    if(!inAQ || !outValue) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioQueueGetParameter,
        LC32_AUDIO_U32((uintptr_t)inAQ), LC32_AUDIO_U32(inParamID),
        LC32_AUDIO_U32((uintptr_t)outValue));
}

OSStatus AudioSessionInitialize(CFRunLoopRef inRunLoop, CFStringRef inRunLoopMode, AudioSessionInterruptionListener inInterruptionListener, void * inClientData) {
    /*
     * The host half initializes the process-wide legacy AudioSession lazily
     * before the first operation. Interruption callback forwarding remains a
     * separate bridge concern, so retain the compatibility no-op here.
     */
    (void)inRunLoop;
    (void)inRunLoopMode;
    (void)inInterruptionListener;
    (void)inClientData;
    return noErr;
}
OSStatus AudioSessionSetActive(Boolean active) {
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioSessionSetActive,
        LC32_AUDIO_U32(active != false));
}

OSStatus AudioSessionSetProperty(AudioSessionPropertyID inID, UInt32 inDataSize, const void * inData) {
    if(inDataSize && !inData) return kAudio_ParamError;
    const OSStatus status = (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioSessionSetProperty,
        LC32_AUDIO_U32(inID), LC32_AUDIO_U32(inDataSize),
        LC32_AUDIO_U32((uintptr_t)inData));
    if(status == noErr &&
       inID == kAudioSessionProperty_PreferredHardwareIOBufferDuration &&
       inDataSize == sizeof(Float32)) {
        uint32_t durationBits;
        memcpy(&durationBits, inData, sizeof(durationBits));
        __atomic_store_n(&LC32PreferredIOBufferDurationBits, durationBits,
            __ATOMIC_RELEASE);
    }
    return status;
}

OSStatus AudioSessionAddPropertyListener(
        AudioSessionPropertyID inID,
        AudioSessionPropertyListener inProc,
        void *inClientData) {
    /*
     * Modern AVAudioSession notifications cover the properties used by old
     * applications.  Keep registration source-compatible for now; forwarding
     * the callback itself requires a host-to-guest trampoline and is added
     * independently of the legacy API's basic availability.
     */
    (void)inID;
    (void)inProc;
    (void)inClientData;
    return noErr;
}

OSStatus AudioSessionRemovePropertyListener(AudioSessionPropertyID inID) {
    (void)inID;
    return noErr;
}

OSStatus AudioSessionRemovePropertyListenerWithUserData(
        AudioSessionPropertyID inID,
        AudioSessionPropertyListener inProc,
        void *inClientData) {
    (void)inID;
    (void)inProc;
    (void)inClientData;
    return noErr;
}

OSStatus AudioSessionGetProperty(AudioSessionPropertyID property,
                                 UInt32 *ioDataSize,
                                 void *outData) {
    if(!ioDataSize) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioSessionGetProperty,
        LC32_AUDIO_U32(property),
        LC32_AUDIO_U32((uintptr_t)ioDataSize),
        LC32_AUDIO_U32((uintptr_t)outData));
}

#pragma mark Audio File Services

OSStatus AudioFileCreateWithURL(
        CFURLRef fileURL,
        AudioFileTypeID fileType,
        const AudioStreamBasicDescription *format,
        AudioFileFlags flags,
        AudioFileID *outAudioFile) {
    if(!fileURL || !format || !outAudioFile) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileCreateWithURL,
        [(id)fileURL host_self], LC32_AUDIO_U32(fileType),
        LC32_AUDIO_U32((uintptr_t)format), LC32_AUDIO_U32(flags),
        LC32_AUDIO_U32((uintptr_t)outAudioFile));
}

OSStatus AudioFileOpenURL(CFURLRef fileURL,
                          AudioFilePermissions permissions,
                          AudioFileTypeID fileTypeHint,
                          AudioFileID *outAudioFile) {
    if(!fileURL || !outAudioFile) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileOpenURL,
        [(id)fileURL host_self], LC32_AUDIO_U32(permissions),
        LC32_AUDIO_U32(fileTypeHint),
        LC32_AUDIO_U32((uintptr_t)outAudioFile));
}

OSStatus AudioFileOpenWithCallbacks(
        void *clientData, AudioFile_ReadProc readFunction,
        AudioFile_WriteProc writeFunction,
        AudioFile_GetSizeProc getSizeFunction,
        AudioFile_SetSizeProc setSizeFunction,
        AudioFileTypeID fileTypeHint, AudioFileID *outAudioFile) {
    if(outAudioFile) *outAudioFile = NULL;
    if(!readFunction || !getSizeFunction || !outAudioFile)
        return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileOpenWithCallbacks,
        LC32_AUDIO_U32((uintptr_t)clientData),
        LC32_AUDIO_U32((uintptr_t)readFunction),
        LC32_AUDIO_U32((uintptr_t)writeFunction),
        LC32_AUDIO_U32((uintptr_t)getSizeFunction),
        LC32_AUDIO_U32((uintptr_t)setSizeFunction),
        LC32_AUDIO_U32(fileTypeHint),
        LC32_AUDIO_U32((uintptr_t)outAudioFile));
}

OSStatus AudioFileGetProperty(AudioFileID audioFile,
                              AudioFilePropertyID property,
                              UInt32 *ioDataSize,
                              void *outData) {
    if(!audioFile || !ioDataSize) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileGetProperty,
        LC32_AUDIO_U32((uintptr_t)audioFile),
        LC32_AUDIO_U32(property),
        LC32_AUDIO_U32((uintptr_t)ioDataSize),
        LC32_AUDIO_U32((uintptr_t)outData));
}

OSStatus AudioFileGetPropertyInfo(AudioFileID audioFile,
                                  AudioFilePropertyID property,
                                  UInt32 *outDataSize,
                                  UInt32 *isWritable) {
    if(!audioFile) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileGetPropertyInfo,
        LC32_AUDIO_U32((uintptr_t)audioFile),
        LC32_AUDIO_U32(property),
        LC32_AUDIO_U32((uintptr_t)outDataSize),
        LC32_AUDIO_U32((uintptr_t)isWritable));
}

OSStatus AudioFileReadBytes(AudioFileID audioFile,
                            Boolean useCache,
                            SInt64 startingByte,
                            UInt32 *ioNumBytes,
                            void *outBuffer) {
    if(!audioFile || !ioNumBytes) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileReadBytes,
        LC32_AUDIO_U32((uintptr_t)audioFile), LC32_AUDIO_U32(useCache),
        (uint64_t)startingByte,
        LC32_AUDIO_U32((uintptr_t)ioNumBytes),
        LC32_AUDIO_U32((uintptr_t)outBuffer));
}

OSStatus AudioFileReadPackets(
        AudioFileID audioFile,
        Boolean useCache,
        UInt32 *outNumBytes,
        AudioStreamPacketDescription *outPacketDescriptions,
        SInt64 startingPacket,
        UInt32 *ioNumPackets,
        void *outBuffer) {
    if(!audioFile || !outNumBytes || !ioNumPackets)
        return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileReadPackets,
        LC32_AUDIO_U32((uintptr_t)audioFile), LC32_AUDIO_U32(useCache),
        LC32_AUDIO_U32((uintptr_t)outNumBytes),
        LC32_AUDIO_U32((uintptr_t)outPacketDescriptions),
        (uint64_t)startingPacket,
        LC32_AUDIO_U32((uintptr_t)ioNumPackets),
        LC32_AUDIO_U32((uintptr_t)outBuffer));
}

OSStatus AudioFileReadPacketData(
        AudioFileID audioFile, Boolean useCache,
        UInt32 *ioNumBytes,
        AudioStreamPacketDescription *outPacketDescriptions,
        SInt64 startingPacket, UInt32 *ioNumPackets,
        void *outBuffer) {
    if(!audioFile || !ioNumBytes || !ioNumPackets)
        return kAudio_ParamError;
    if(*ioNumBytes && !outBuffer) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileReadPacketData,
        LC32_AUDIO_U32((uintptr_t)audioFile), LC32_AUDIO_U32(useCache),
        LC32_AUDIO_U32((uintptr_t)ioNumBytes),
        LC32_AUDIO_U32((uintptr_t)outPacketDescriptions),
        (uint64_t)startingPacket,
        LC32_AUDIO_U32((uintptr_t)ioNumPackets),
        LC32_AUDIO_U32((uintptr_t)outBuffer));
}

OSStatus AudioFileWriteBytes(AudioFileID audioFile,
                             Boolean useCache,
                             SInt64 startingByte,
                             UInt32 *ioNumBytes,
                             const void *inBuffer) {
    if(!audioFile || !ioNumBytes) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileWriteBytes,
        LC32_AUDIO_U32((uintptr_t)audioFile), LC32_AUDIO_U32(useCache),
        (uint64_t)startingByte,
        LC32_AUDIO_U32((uintptr_t)ioNumBytes),
        LC32_AUDIO_U32((uintptr_t)inBuffer));
}

OSStatus AudioFileClose(AudioFileID audioFile) {
    if(!audioFile) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileClose,
        LC32_AUDIO_U32((uintptr_t)audioFile));
}

#pragma mark Audio File Stream Services

OSStatus AudioFileStreamOpen(void *clientData,
        AudioFileStream_PropertyListenerProc propertyListener,
        AudioFileStream_PacketsProc packetsProc, AudioFileTypeID hint,
        AudioFileStreamID *outStream) {
    if(outStream) *outStream = NULL;
    if(!propertyListener || !packetsProc || !outStream)
        return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(LC32AudioToolboxOpAudioFileStreamOpen,
        LC32_AUDIO_U32((uintptr_t)clientData),
        LC32_AUDIO_U32((uintptr_t)propertyListener),
        LC32_AUDIO_U32((uintptr_t)packetsProc), LC32_AUDIO_U32(hint),
        LC32_AUDIO_U32((uintptr_t)outStream));
}

OSStatus AudioFileStreamParseBytes(AudioFileStreamID stream, UInt32 size,
        const void *bytes, AudioFileStreamParseFlags flags) {
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileStreamParseBytes,
        LC32_AUDIO_U32((uintptr_t)stream), LC32_AUDIO_U32(size),
        LC32_AUDIO_U32((uintptr_t)bytes), LC32_AUDIO_U32(flags));
}

OSStatus AudioFileStreamGetPropertyInfo(AudioFileStreamID stream,
        AudioFileStreamPropertyID property, UInt32 *size, Boolean *writable) {
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileStreamGetPropertyInfo,
        LC32_AUDIO_U32((uintptr_t)stream), LC32_AUDIO_U32(property),
        LC32_AUDIO_U32((uintptr_t)size),
        LC32_AUDIO_U32((uintptr_t)writable));
}

OSStatus AudioFileStreamGetProperty(AudioFileStreamID stream,
        AudioFileStreamPropertyID property, UInt32 *size, void *data) {
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileStreamGetProperty,
        LC32_AUDIO_U32((uintptr_t)stream), LC32_AUDIO_U32(property),
        LC32_AUDIO_U32((uintptr_t)size), LC32_AUDIO_U32((uintptr_t)data));
}

OSStatus AudioFileStreamSeek(AudioFileStreamID stream, SInt64 packetOffset,
        SInt64 *byteOffset, AudioFileStreamSeekFlags *flags) {
    return (OSStatus)LC32_AUDIO_CALL(LC32AudioToolboxOpAudioFileStreamSeek,
        LC32_AUDIO_U32((uintptr_t)stream), (uint64_t)packetOffset,
        LC32_AUDIO_U32((uintptr_t)byteOffset),
        LC32_AUDIO_U32((uintptr_t)flags));
}

OSStatus AudioFileStreamSetProperty(AudioFileStreamID stream,
        AudioFileStreamPropertyID property, UInt32 size, const void *data) {
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpAudioFileStreamSetProperty,
        LC32_AUDIO_U32((uintptr_t)stream), LC32_AUDIO_U32(property),
        LC32_AUDIO_U32(size), LC32_AUDIO_U32((uintptr_t)data));
}

OSStatus AudioFileStreamClose(AudioFileStreamID stream) {
    return (OSStatus)LC32_AUDIO_CALL(LC32AudioToolboxOpAudioFileStreamClose,
        LC32_AUDIO_U32((uintptr_t)stream));
}

#pragma mark Extended Audio File Services

OSStatus ExtAudioFileOpenURL(CFURLRef url, ExtAudioFileRef *outFile) {
    if(!url || !outFile) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpExtAudioFileOpenURL,
        [(id)url host_self], LC32_AUDIO_U32((uintptr_t)outFile));
}

OSStatus ExtAudioFileWrapAudioFileID(AudioFileID audioFile,
                                    Boolean forWriting,
                                    ExtAudioFileRef *outFile) {
    if(!audioFile || !outFile) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpExtAudioFileWrapAudioFileID,
        LC32_AUDIO_U32((uintptr_t)audioFile), LC32_AUDIO_U32(forWriting),
        LC32_AUDIO_U32((uintptr_t)outFile));
}

OSStatus ExtAudioFileDispose(ExtAudioFileRef file) {
    if(!file) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpExtAudioFileDispose,
        LC32_AUDIO_U32((uintptr_t)file));
}

OSStatus ExtAudioFileGetProperty(ExtAudioFileRef file,
                                 ExtAudioFilePropertyID property,
                                 UInt32 *ioDataSize,
                                 void *outData) {
    if(!file || !ioDataSize) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpExtAudioFileGetProperty,
        LC32_AUDIO_U32((uintptr_t)file), LC32_AUDIO_U32(property),
        LC32_AUDIO_U32((uintptr_t)ioDataSize),
        LC32_AUDIO_U32((uintptr_t)outData));
}

OSStatus ExtAudioFileSetProperty(ExtAudioFileRef file,
                                 ExtAudioFilePropertyID property,
                                 UInt32 dataSize,
                                 const void *data) {
    if(!file || (dataSize && !data)) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpExtAudioFileSetProperty,
        LC32_AUDIO_U32((uintptr_t)file), LC32_AUDIO_U32(property),
        LC32_AUDIO_U32(dataSize), LC32_AUDIO_U32((uintptr_t)data));
}

OSStatus ExtAudioFileRead(ExtAudioFileRef file,
                          UInt32 *ioNumberFrames,
                          AudioBufferList *ioData) {
    if(!file || !ioNumberFrames || !ioData) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpExtAudioFileRead,
        LC32_AUDIO_U32((uintptr_t)file),
        LC32_AUDIO_U32((uintptr_t)ioNumberFrames),
        LC32_AUDIO_U32((uintptr_t)ioData));
}

OSStatus ExtAudioFileSeek(ExtAudioFileRef file, SInt64 frameOffset) {
    if(!file) return kAudio_ParamError;
    return (OSStatus)LC32_AUDIO_CALL(
        LC32AudioToolboxOpExtAudioFileSeek,
        LC32_AUDIO_U32((uintptr_t)file),
        (uint64_t)frameOffset);
}
